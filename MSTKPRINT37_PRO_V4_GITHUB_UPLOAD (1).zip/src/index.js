const PRODUCTS = {
  "figurine-personnalisee": { name:"Figurine personnalisée", price:12.90, icon:"🧸", category:"Figurines", desc:"Une figurine originale fabriquée à la demande à partir de ton idée." },
  "porte-cles-personnalise": { name:"Porte-clés personnalisé", price:2.50, icon:"🔑", category:"Porte-clés", desc:"Prénom, logo ou petit symbole imprimé en 3D." },
  "deco-murale": { name:"Décoration murale", price:9.90, icon:"🖼️", category:"Décoration", desc:"Une décoration légère et originale pour personnaliser un mur." },
  "cadeau-personnalise": { name:"Cadeau personnalisé", price:7.90, icon:"🎁", category:"Cadeaux", desc:"Un objet créé spécialement pour une occasion ou une personne." },
  "cadre-photo-led": { name:"Cadre photo LED", price:24.90, icon:"💡", category:"Photo & LED", desc:"Un cadre lumineux personnalisé pour mettre en valeur un souvenir." },
  "plaque-personnalisee": { name:"Plaque personnalisée", price:9.90, icon:"🏷️", category:"Décoration", desc:"Texte, prénom ou message transformé en plaque imprimée en 3D." }
};

const NAV = [
 ["Boutique","/boutique"],["Personnaliser","/personnaliser"],["Services","/services"],["Galerie","/galerie"],["À propos","/a-propos"]
];

const PAGES = {
  "/nouveautes": ["Nouveautés","Les dernières créations et nouveautés sorties de l’atelier.", productGrid(["figurine-personnalisee","cadre-photo-led","plaque-personnalisee"])],
  "/promotions": ["Promotions","Retrouve ici les offres et packs disponibles en ce moment.", `<div class="grid cols-2"><div class="card"><span class="tag">Offre</span><h2>4 figurines achetées, la 5e offerte</h2><p>Compose ton pack directement avec nous. Offre selon disponibilité des modèles.</p><a class="btn primary" href="/contact">En profiter</a></div><div class="card"><span class="tag">Livraison</span><h2>Offerte dès 49 €</h2><p>La livraison standard passe automatiquement à 0 € lorsque le panier atteint le seuil.</p><a class="btn" href="/boutique">Voir la boutique</a></div></div>`],
  "/services": ["Services d’impression 3D","De l’idée au véritable objet : création, adaptation et fabrication.", `<div class="grid cols-3">
    ${feature("🧠","Création sur mesure","Décris ton idée, envoie une image ou un croquis et nous étudions la faisabilité.")}
    ${feature("🧩","Création / modification STL","Adaptation de modèles, texte, dimensions, assemblages et préparation à l’impression.")}
    ${feature("🏭","Petites séries","Fabrication de petites quantités pour événements, associations et professionnels.")}
    ${feature("🎁","Cadeaux personnalisés","Prénoms, dates, messages, logos et objets uniques.")}
    ${feature("📐","Prototypage","Une première version pour tester forme, dimensions et usage avant série.")}
    ${feature("💬","Devis personnalisé","Une demande claire, une réponse adaptée au projet et aux quantités.")}
  </div><div class="buttons"><a class="btn primary" href="/personnaliser">Créer mon projet</a><a class="btn" href="/contact">Demander conseil</a></div>`],
  "/galerie": ["Galerie","Quelques univers de créations possibles chez MSTKPRINT37.", `<div class="grid cols-3">
    ${gallery("🧸","Figurines")}${gallery("🔑","Porte-clés")}${gallery("🖼️","Décoration")}
    ${gallery("💡","Cadres LED")}${gallery("🎁","Cadeaux")}${gallery("📐","Prototypes")}
  </div>`],
  "/avis": ["Avis clients","Les retours clients peuvent être reliés ici à ta base NØVA/Supabase.", `<div class="grid cols-3">
    ${review("★★★★★","Création propre et personnalisée","Exemple d’avis — à remplacer par tes vrais avis.")}
    ${review("★★★★★","Très bon échange","Exemple d’avis — validation rapide avant fabrication.")}
    ${review("★★★★★","Cadeau original","Exemple d’avis — parfait pour présenter la section.")}
  </div><div class="notice" style="margin-top:20px">Les textes ci-dessus sont des emplacements de démonstration, pas de faux avis publiés comme authentiques.</div>`],
  "/a-propos": ["À propos de MSTKPRINT37","Une activité dédiée à l’impression 3D personnalisée et aux objets fabriqués à la demande.", `<div class="grid cols-2"><div class="card"><h2>Des idées qui deviennent réelles</h2><p>Le principe : partir d’un besoin, d’un prénom, d’un logo, d’un thème ou d’une idée et le transformer en objet imprimable.</p><p>Chaque projet est préparé pour obtenir un résultat propre, cohérent et adapté à l’usage demandé.</p></div><div class="card"><h2>Fabrication à la demande</h2><p>Pas de production industrielle impersonnelle : les objets sont préparés et imprimés en fonction de la commande.</p><div class="badges"><span class="badge">🇫🇷 France</span><span class="badge">🧩 Personnalisation</span><span class="badge">🖨️ Impression 3D</span></div></div></div>`],
  "/atelier": ["Notre atelier","Les coulisses : conception, préparation, impression et finition.", `<div class="grid cols-4">${step("Conception","Préparation du modèle ou adaptation du fichier.")}${step("Préparation","Choix des paramètres, matière, couleur et orientation.")}${step("Impression","Fabrication couche par couche avec contrôle du déroulement.")}${step("Finition","Retrait des supports, contrôle et préparation de la commande.")}</div>`],
  "/livraison": ["Livraison","Informations générales sur la préparation et l’expédition.", `<div class="grid cols-2"><div class="card"><h3>Fabrication avant expédition</h3><p>La majorité des articles sont fabriqués à la demande. Le délai affiché ou annoncé comprend donc une phase de fabrication avant l’envoi.</p></div><div class="card"><h3>Frais de livraison</h3><p>Le projet est configuré avec une livraison standard à 4,90 € et gratuite à partir de 49 €. Modifie ces valeurs dans <code>wrangler.jsonc</code>.</p></div></div>`],
  "/retours": ["Retours & remboursements","Une page claire pour expliquer le traitement des demandes après achat.", `<div class="legal"><p>Contacte MSTKPRINT37 rapidement avec ta référence de commande et des photos en cas de problème de fabrication ou de transport.</p><div class="notice">Les produits clairement personnalisés peuvent relever d’une exception au droit de rétractation. Adapte les CGV à ton activité et fais-les valider si nécessaire.</div><h2>Produit endommagé ou non conforme</h2><p>Indique la référence, décris le problème et joins des photos permettant d’identifier le défaut.</p><h2>Produit personnalisé</h2><p>Les conditions applicables dépendent de la nature de la personnalisation et de la réglementation en vigueur.</p></div>`],
  "/faq": ["Questions fréquentes","Les réponses essentielles avant de passer commande.", faqHtml()],
  "/contact": ["Contact","Une question, un projet ou besoin d’un devis ? Écris-nous.", contactHtml()],
  "/suivi": ["Suivre ma commande","Entre la référence de commande et l’e-mail utilisé lors de l’achat.", trackHtml()],
  "/compte": ["Mon compte","Retrouve ton profil et l’accès à tes commandes.", accountHtml()],
  "/compte/commandes": ["Mes commandes","Historique et statut de tes commandes.", accountListHtml("orders")],
  "/compte/devis": ["Mes devis","Retrouve les demandes de devis liées à ton compte.", accountListHtml("quotes")],
  "/compte/factures": ["Mes factures","Retrouve tes factures lorsqu’elles sont disponibles.", accountListHtml("invoices")],
  "/panier": ["Mon panier","Vérifie les articles avant de passer commande.", `<div class="grid cols-2" style="grid-template-columns:1.4fr .6fr"><div id="cartItems"></div><div id="cartSummary"></div></div>`],
  "/commande": ["Finaliser la commande","Renseigne les informations nécessaires puis passe au paiement sécurisé.", checkoutHtml()],
  "/personnaliser": ["Créer mon objet","Configure ton projet. L’estimation est indicative avant validation technique.", customizerHtml()],
};

const LEGAL = {
  "/mentions-legales":["Mentions légales",`
  <div class="legal"><p><b>Éditeur :</b> MSTKPRINT37 — Entrepreneur individuel.</p><p><b>Site :</b> mstkprint37.com</p><p><b>Adresse :</b> 44 avenue du Maine, 37110 Château-Renault, France.</p><p><b>Activité :</b> vente et fabrication d’objets imprimés en 3D.</p><p><b>Hébergement :</b> Cloudflare, Inc. — infrastructure Cloudflare Workers.</p><h2>Informations à compléter</h2><div class="notice">Ajoute ici ton SIREN/SIRET, e-mail professionnel, directeur de publication et toute mention obligatoire correspondant exactement à ta situation.</div></div>`],
  "/cgv":["Conditions générales de vente",`
  <div class="legal"><div class="notice">Modèle de structure à personnaliser. Ce fichier n’est pas un avis juridique et doit être adapté à ton activité réelle.</div>
  <h2>1. Objet</h2><p>Les présentes conditions encadrent les ventes réalisées sur le site MSTKPRINT37.</p>
  <h2>2. Produits et personnalisation</h2><p>Les caractéristiques essentielles, dimensions, matières, couleurs et options sont précisées sur la fiche produit ou lors de la validation du projet. Les rendus numériques peuvent différer légèrement de l’objet imprimé.</p>
  <h2>3. Prix</h2><p>Les prix affichés sont ceux applicables au moment de la commande, hors éventuels frais de livraison indiqués avant paiement.</p>
  <h2>4. Commande</h2><p>Le client vérifie le contenu de son panier et les informations fournies avant validation.</p>
  <h2>5. Paiement</h2><p>Le paiement en ligne est traité par le prestataire de paiement configuré sur le site.</p>
  <h2>6. Fabrication et livraison</h2><p>Les délais comprennent, lorsqu’elle est nécessaire, la fabrication à la demande avant expédition.</p>
  <h2>7. Rétractation et produits personnalisés</h2><p>Les règles légales de rétractation s’appliquent sous réserve des exceptions prévues par la réglementation, notamment pour certains biens confectionnés selon les spécifications du consommateur ou nettement personnalisés.</p>
  <h2>8. Garanties</h2><p>Les garanties légales applicables restent dues dans les conditions prévues par la loi.</p>
  <h2>9. Réclamations et médiation</h2><p>Le client peut contacter MSTKPRINT37. Les coordonnées du médiateur de la consommation doivent être complétées dans la page Médiation.</p></div>`],
  "/confidentialite":["Politique de confidentialité",`
  <div class="legal"><p>Cette page décrit la structure prévue pour informer les visiteurs sur les données traitées par le site.</p><h2>Données concernées</h2><p>Compte client, coordonnées de livraison, commandes, demandes de devis, messages de contact et informations techniques nécessaires au fonctionnement.</p><h2>Finalités</h2><p>Gestion des demandes, exécution des commandes, suivi client, sécurité et obligations administratives.</p><h2>Durées et droits</h2><p>Complète les durées de conservation réelles et l’adresse à utiliser pour exercer les droits d’accès, rectification, effacement ou opposition lorsque ceux-ci sont applicables.</p><h2>Sous-traitants</h2><p>Cloudflare, Supabase et le prestataire de paiement peuvent intervenir selon ta configuration.</p></div>`],
  "/cookies":["Cookies",`
  <div class="legal"><p>Le site mémorise ton panier et tes préférences indispensables à son fonctionnement.</p><p>Les traceurs non nécessaires ne doivent être activés qu’en fonction du choix du visiteur lorsque le consentement est requis.</p><h2>Préférences</h2><p>Le bandeau inclus dans ce projet permet d’enregistrer un choix « essentiel uniquement » ou « accepter ». Branche ensuite tes outils de mesure d’audience sur ce choix.</p></div>`],
  "/mediation":["Médiation de la consommation",`
  <div class="legal"><div class="notice">À compléter avant mise en ligne avec le médiateur de la consommation dont tu dépends et ses coordonnées exactes.</div><p>En cas de litige non résolu après une réclamation écrite préalable, le consommateur peut recourir au dispositif de médiation de la consommation applicable.</p></div>`]
};

function feature(icon,title,text){return `<div class="card feature"><div class="feature-icon">${icon}</div><div><h3>${title}</h3><p>${text}</p></div></div>`}
function gallery(icon,title){return `<div class="card category-card"><div class="bigicon">${icon}</div><span>CRÉATIONS</span><h3>${title}</h3></div>`}
function review(stars,title,text){return `<div class="card"><div style="color:#ff9c57">${stars}</div><h3>${title}</h3><p>${text}</p></div>`}
function step(title,text){return `<div class="card step"><h3>${title}</h3><p>${text}</p></div>`}
function productCard(slug){
 const p=PRODUCTS[slug];return `<article class="card product-card"><a href="/produit/${slug}"><div class="product-visual">${p.icon}</div></a><div class="product-info"><div class="product-top"><div><span class="tag">${p.category}</span><h3><a href="/produit/${slug}">${p.name}</a></h3></div><div class="price">dès ${p.price.toFixed(2).replace('.',',')} €</div></div><p>${p.desc}</p><div class="buttons"><a class="btn" href="/produit/${slug}">Voir</a><button class="btn primary" data-add="${slug}" data-name="${p.name}" data-price="${p.price}" data-icon="${p.icon}">Ajouter</button></div></div></article>`
}
function productGrid(list=Object.keys(PRODUCTS)){return `<div class="grid cols-3">${list.map(productCard).join("")}</div>`}
function faqHtml(){return `<div class="faq">
 <details open><summary>Peut-on demander un objet qui n’est pas dans la boutique ?</summary><p>Oui. Utilise la page « Créer mon objet » ou le formulaire de contact.</p></details>
 <details><summary>Les objets sont-ils fabriqués à la demande ?</summary><p>Oui pour la plupart des créations, en particulier les personnalisations.</p></details>
 <details><summary>Puis-je envoyer une photo ou un logo ?</summary><p>Oui. Le formulaire de personnalisation prévoit la description du projet ; l’envoi de fichier peut être relié ensuite à Supabase Storage.</p></details>
 <details><summary>Comment suivre ma commande ?</summary><p>Utilise ta référence et ton e-mail sur la page de suivi ou connecte-toi à ton compte.</p></details>
 <details><summary>Quels moyens de paiement ?</summary><p>Le projet inclut un checkout SumUp hébergé dès que les clés SumUp sont configurées dans Cloudflare.</p></details>
 </div>`}
function contactHtml(){return `<div class="grid cols-2"><div><h2>Parlons de ton projet</h2><p class="lead">Décris ce que tu veux fabriquer, la quantité et les dimensions si tu les connais.</p><div class="card"><b>MSTKPRINT37</b><p>44 Av. du Maine<br>37110 Château-Renault</p><p>Site : mstkprint37.com</p></div></div><div><form class="card form" data-api="/api/contact" data-success="Message envoyé"><div class="form-row"><div class="field"><label>Nom</label><input class="input" name="name" required></div><div class="field"><label>E-mail</label><input class="input" type="email" name="email" required></div></div><div class="field"><label>Sujet</label><input class="input" name="subject" required></div><div class="field"><label>Message</label><textarea class="textarea" name="message" required></textarea></div><button class="btn primary" type="submit">Envoyer</button></form><div data-form-result></div></div></div>`}
function trackHtml(){return `<div class="grid cols-2"><form class="card form" id="trackForm"><div class="field"><label>Référence</label><input class="input" name="reference" placeholder="CMD-2026-..." required></div><div class="field"><label>E-mail</label><input class="input" type="email" name="email" required></div><button class="btn primary">Rechercher</button></form><div id="trackResult"><div class="card"><h3>Suivi centralisé</h3><p>Le statut provient de Supabase lorsque la connexion est configurée.</p></div></div></div>`}
function accountNav(active="/compte"){return `<nav class="card sidebar"><a class="${active==='/compte'?'active':''}" href="/compte">Profil</a><a class="${active.includes('commandes')?'active':''}" href="/compte/commandes">Commandes</a><a class="${active.includes('devis')?'active':''}" href="/compte/devis">Devis</a><a class="${active.includes('factures')?'active':''}" href="/compte/factures">Factures</a></nav>`}
function accountHtml(){return `<div class="account-grid">${accountNav("/compte")}<div><div id="accountData"></div><div class="grid cols-2" style="margin-top:16px"><form class="card form" id="loginForm"><h3>Connexion</h3><div class="field"><label>E-mail</label><input class="input" type="email" name="email" required></div><div class="field"><label>Mot de passe</label><input class="input" type="password" name="password" required></div><button class="btn primary">Se connecter</button></form><form class="card form" id="signupForm"><h3>Créer un compte</h3><div class="field"><label>E-mail</label><input class="input" type="email" name="email" required></div><div class="field"><label>Mot de passe</label><input class="input" type="password" minlength="8" name="password" required></div><button class="btn">Créer mon compte</button></form></div><button class="btn ghost" data-logout style="margin-top:16px">Se déconnecter</button></div></div>`}
function accountListHtml(type){const path=type==="orders"?"/compte/commandes":type==="quotes"?"/compte/devis":"/compte/factures";return `<div class="account-grid">${accountNav(path)}<div data-account-list="${type}"><div class="card">Chargement…</div></div></div>`}
function checkoutHtml(){return `<div class="grid cols-2"><div><form class="card form" id="checkoutForm"><h3>Informations client</h3><div class="form-row"><div class="field"><label>Prénom</label><input class="input" name="first_name" required></div><div class="field"><label>Nom</label><input class="input" name="last_name" required></div></div><div class="field"><label>E-mail</label><input class="input" type="email" name="email" required></div><div class="field"><label>Téléphone</label><input class="input" name="phone"></div><div class="field"><label>Adresse</label><input class="input" name="address" required></div><div class="form-row"><div class="field"><label>Code postal</label><input class="input" name="postal_code" required></div><div class="field"><label>Ville</label><input class="input" name="city" required></div></div><label class="small"><input type="checkbox" required> J’accepte les CGV et confirme les informations de la commande.</label><button class="btn primary" type="submit">Payer avec SumUp</button></form></div><div><div class="card" id="checkoutList">Chargement…</div></div></div>`}
function customizerHtml(){return `<div class="grid cols-2"><form class="card form" id="customizerForm" data-api="/api/quotes" data-success="Demande envoyée à MSTKPRINT37"><div class="field"><label>Type d’objet</label><select class="select" name="object_type"><option data-price="12.9">Figurine</option><option data-price="2.5">Porte-clés</option><option data-price="9.9">Décoration / plaque</option><option data-price="24.9">Cadre LED</option><option data-price="7.9">Autre objet personnalisé</option></select></div><div class="field"><label>Taille</label><select class="select" name="size"><option data-factor=".85">Petit</option><option data-factor="1" selected>Standard</option><option data-factor="1.6">Grand</option><option data-factor="2.4">Très grand</option></select></div><div class="form-row"><div class="field"><label>Couleur</label><input class="input" name="color" placeholder="Orange, noir..."></div><div class="field"><label>Quantité</label><input class="input" name="quantity" type="number" min="1" value="1"></div></div><div class="field"><label>Texte / prénom</label><input class="input" name="custom_text"></div><div class="field"><label>Décris ton idée</label><textarea class="textarea" name="description" required placeholder="Forme, thème, usage, détails importants..."></textarea></div><div class="form-row"><div class="field"><label>Nom</label><input class="input" name="name" required></div><div class="field"><label>E-mail</label><input class="input" type="email" name="email" required></div></div><button class="btn primary" type="submit">Envoyer ma demande</button></form><div><div class="card summary"><span class="tag">ESTIMATION</span><h2 id="estimate">—</h2><p>Estimation indicative basée sur le type, la taille et la quantité. Le prix final dépend du modèle, de la matière, du temps d’impression et des finitions.</p><hr><div class="feature"><div class="feature-icon">✓</div><div><b>Validation avant fabrication</b><div class="muted small">Le projet peut être ajusté avant lancement.</div></div></div></div></div></div>`}

function home(){
 return `<section class="hero"><div class="container hero-grid"><div><span class="eyebrow">🖨️ Impression 3D personnalisée</span><h1>Vos idées<br><span style="color:var(--accent)">prennent forme.</span></h1><p class="lead">Objets personnalisés, cadeaux, figurines, décoration et créations sur mesure fabriqués à la demande.</p><div class="buttons"><a class="btn primary" href="/personnaliser">Créer mon objet</a><a class="btn secondary" href="/boutique">Découvrir la boutique</a></div><div class="stats"><div class="stat"><b>Sur mesure</b><span>Personnalisation</span></div><div class="stat"><b>France</b><span>Fabrication</span></div><div class="stat"><b>3D</b><span>Création</span></div><div class="stat"><b>NØVA</b><span>Suivi client</span></div></div></div><div class="hero-card"><div class="printer"><div class="nozzle"></div><div class="filament"></div><div class="print-object"></div></div></div></div></section>
 <section class="section alt"><div class="container"><div class="section-head"><div><span class="eyebrow">CATÉGORIES</span><h2>Qu’est-ce qu’on fabrique ?</h2></div><p>Une boutique courte, lisible et orientée personnalisation.</p></div><div class="grid cols-4">
 ${gallery("🧸","Figurines")}${gallery("🔑","Porte-clés")}${gallery("🖼️","Décoration")}${gallery("🎁","Cadeaux personnalisés")}
 </div></div></section>
 <section class="section"><div class="container"><div class="section-head"><div><span class="eyebrow">SÉLECTION</span><h2>Les créations du moment</h2></div><a class="btn" href="/boutique">Tout voir</a></div>${productGrid(["figurine-personnalisee","porte-cles-personnalise","cadre-photo-led"])}</div></section>
 <section class="section alt"><div class="container"><div class="section-head"><div><span class="eyebrow">SIMPLE</span><h2>De l’idée à l’objet</h2></div></div><div class="grid cols-3">${step("Décris ton idée","Choisis un produit ou utilise le configurateur pour expliquer ton projet.")}${step("Validation","Les détails, dimensions et contraintes sont vérifiés avant fabrication.")}${step("Fabrication","L’objet est imprimé, contrôlé puis préparé pour l’expédition.")}</div></div></section>
 <section class="section"><div class="container"><div class="grid cols-2"><div><span class="eyebrow">SUR MESURE</span><h2>Tu ne trouves pas exactement ce que tu veux ?</h2><p class="lead">C’est justement là que l’impression 3D devient intéressante.</p><div class="buttons"><a class="btn primary" href="/personnaliser">Lancer mon projet</a><a class="btn" href="/contact">Nous contacter</a></div></div><div class="card">${feature("📐","Dimensions personnalisées","Adapte la taille au besoin réel.")}${feature("✍️","Texte et prénom","Ajoute une personnalisation unique.")}${feature("🧩","Projet spécial","Décris une création qui n’existe pas encore en boutique.")}</div></div></div></section>`;
}
function boutique(){return `<div class="section"><div class="container"><div class="section-head"><div><span class="eyebrow">BOUTIQUE</span><h2>Objets imprimés en 3D</h2></div><p>Prix de départ. Les variantes et personnalisations peuvent modifier le tarif final.</p></div>${productGrid()}</div></div>`}
function productPage(slug){
 const p=PRODUCTS[slug];if(!p)return null;
 return `<section class="pagehero"><div class="container"><span class="eyebrow">${p.category}</span><h1>${p.name}</h1><p>${p.desc}</p></div></section><section class="section"><div class="container grid cols-2"><div class="hero-card" style="min-height:430px;display:grid;place-items:center;font-size:150px">${p.icon}</div><div><span class="tag">FABRICATION À LA DEMANDE</span><h2 style="margin-top:14px">À partir de ${p.price.toFixed(2).replace('.',',')} €</h2><p class="lead">${p.desc}</p><div class="card"><h3>Personnalisation possible</h3><p>Couleur, texte, dimensions ou détails selon le modèle et la faisabilité.</p></div><div class="buttons"><button class="btn primary" data-add="${slug}" data-name="${p.name}" data-price="${p.price}" data-icon="${p.icon}">Ajouter au panier</button><a class="btn" href="/personnaliser">Personnaliser</a></div><p class="muted small">Le rendu et le délai peuvent varier selon la personnalisation choisie.</p></div></div></section>`;
}

function novaAdminHtml(){return `<section class="pagehero"><div class="container"><span class="eyebrow">NØVA — BY MSTK</span><h1>Administration</h1><p>Console privée pour suivre l’activité essentielle du site.</p></div></section><section class="section"><div class="container"><div id="novaRoot"><div class="grid cols-2"><form class="card form" id="novaLogin"><h2>Accès NØVA</h2><div class="field"><label>PIN administrateur</label><input class="input" name="pin" inputmode="numeric" autocomplete="one-time-code" required></div><button class="btn primary">Déverrouiller</button></form><div class="card"><h3>Session sécurisée</h3><p>Le PIN est vérifié côté Worker et n’est jamais intégré au JavaScript public. La session est conservée dans un cookie HttpOnly.</p><div id="novaLoginMessage"></div></div></div></div></div></section>`}
function pageShell(path,title,content,description){
 const nav=NAV.map(([n,u])=>`<a class="${path===u?'active':''}" href="${u}">${n}</a>`).join("");
 return `<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><title>${escapeHtml(title)} | MSTKPRINT37</title><meta name="description" content="${escapeHtml(description||"Impression 3D personnalisée, créations sur mesure et cadeaux originaux.")}"><meta name="theme-color" content="#0c0d10"><link rel="manifest" href="/manifest.webmanifest"><link rel="stylesheet" href="/styles.css"><script type="application/ld+json">${JSON.stringify({"@context":"https://schema.org","@type":"Organization","name":"MSTKPRINT37","url":"https://mstkprint37.com"})}</script></head><body>
 <div class="topbar">Fabrication à la demande • Personnalisation • Livraison offerte dès 49 €</div>
 <header class="header"><div class="container nav"><a class="brand" href="/"><span class="brand-mark">M</span>MSTKPRINT37</a><nav class="navlinks" id="navlinks">${nav}</nav><div class="actions"><button class="iconbtn" id="searchBtn" aria-label="Rechercher">⌕</button><a class="iconbtn" href="/compte" aria-label="Compte">👤</a><a class="iconbtn" href="/panier" aria-label="Panier">🛒 <span class="cartbadge" data-cart-count>0</span></a><button class="iconbtn mobile-toggle" id="mobileToggle">☰</button></div></div></header>
 <main>${content}</main>${footer()}
 <div class="searchbox" id="searchBox"><div class="searchpanel"><div style="display:flex;gap:8px"><input class="input" id="siteSearch" placeholder="Rechercher un produit ou une page…"><button class="iconbtn" id="searchClose">✕</button></div><div class="searchresults" id="searchResults"></div></div></div>
 <div class="cookie" id="cookieBanner"><b>Respect de tes préférences</b><p>Le site utilise le stockage nécessaire au panier et au fonctionnement. Les outils non essentiels doivent respecter ton choix.</p><div class="cookie-actions"><button class="btn primary" data-cookie="all">Accepter</button><button class="btn" data-cookie="essential">Essentiel uniquement</button><a class="btn ghost" href="/cookies">En savoir plus</a></div></div><div class="toast" id="toast"></div><script src="/app.js" defer></script></body></html>`;
}
function footer(){return `<footer class="footer"><div class="container"><div class="footer-grid"><div><a class="brand" href="/"><span class="brand-mark">M</span>MSTKPRINT37</a><p class="muted">Impression 3D personnalisée et fabrication à la demande.</p><div class="badges"><span class="badge">Paiement sécurisé</span><span class="badge">Fabrication France</span></div></div><div><h4>Boutique</h4><a href="/boutique">Tous les produits</a><a href="/nouveautes">Nouveautés</a><a href="/promotions">Promotions</a><a href="/personnaliser">Créer mon objet</a></div><div><h4>Aide</h4><a href="/faq">FAQ</a><a href="/livraison">Livraison</a><a href="/retours">Retours</a><a href="/suivi">Suivi de commande</a><a href="/contact">Contact</a></div><div><h4>Informations</h4><a href="/a-propos">À propos</a><a href="/mentions-legales">Mentions légales</a><a href="/cgv">CGV</a><a href="/confidentialite">Confidentialité</a><a href="/cookies">Cookies</a><a href="/mediation">Médiation</a></div></div><div class="copyright"><span>© ${new Date().getFullYear()} MSTKPRINT37 — Tous droits réservés.</span><span>Propulsé par Cloudflare Workers • NØVA ready</span></div></div></footer>`}
function pageContent(path){
 if(path==="/")return pageShell(path,"Impression 3D personnalisée",home(),"Créations et objets personnalisés imprimés en 3D.");
 if(path==="/boutique")return pageShell(path,"Boutique",boutique(),"Boutique d’objets imprimés en 3D.");
 if(path.startsWith("/produit/")){const slug=path.slice(9),c=productPage(slug);return c?pageShell(path,PRODUCTS[slug].name,c,PRODUCTS[slug].desc):null}
 const page=PAGES[path];
 if(page)return pageShell(path,page[0],`<section class="pagehero"><div class="container"><span class="eyebrow">MSTKPRINT37</span><h1>${page[0]}</h1><p>${page[1]}</p></div></section><section class="section"><div class="container">${page[2]}</div></section>`,page[1]);
 const legal=LEGAL[path];
 if(legal)return pageShell(path,legal[0],`<section class="pagehero"><div class="container"><span class="eyebrow">INFORMATIONS</span><h1>${legal[0]}</h1><p>Informations importantes concernant le site et les achats.</p></div></section><section class="section"><div class="container">${legal[1]}</div></section>`,legal[0]+" — informations MSTKPRINT37");
 if(path==="/nova")return pageShell(path,"NØVA — Administration",novaAdminHtml(),"Administration privée MSTKPRINT37");
 return null;
}
function escapeHtml(s=""){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
function json(data,status=200,headers={}){return new Response(JSON.stringify(data),{status,headers:{"content-type":"application/json;charset=utf-8","cache-control":"no-store",...headers}})}
async function body(req){try{return await req.json()}catch{return {}}}
function bearer(req){const h=req.headers.get("authorization")||"";return h.startsWith("Bearer ")?h.slice(7):""}
function supabaseReady(env){return !!(env.SUPABASE_URL&&env.SUPABASE_SERVICE_ROLE_KEY)}
async function sb(env,path,{method="GET",payload,token,prefer}={}){
 const key=token?env.SUPABASE_ANON_KEY:env.SUPABASE_SERVICE_ROLE_KEY;
 const headers={"apikey":key,"Authorization":`Bearer ${token||key}`,"Content-Type":"application/json"};
 if(prefer)headers.Prefer=prefer;
 const r=await fetch(`${env.SUPABASE_URL}${path}`,{method,headers,body:payload?JSON.stringify(payload):undefined});
 const text=await r.text();let data={};try{data=JSON.parse(text)}catch{data={raw:text}}
 if(!r.ok)throw new Error(data.msg||data.message||data.error_description||`Supabase ${r.status}`);
 return data;
}
async function nova(env,type,payload){
 if(!env.NOVA_API_URL)return;
 const map={client:"/clients",order:"/orders",quote:"/quotes",contact:"/contacts"};
 try{await fetch(env.NOVA_API_URL.replace(/\/$/,"")+(map[type]||"/events"),{method:"POST",headers:{"Content-Type":"application/json",...(env.NOVA_API_KEY?{"Authorization":`Bearer ${env.NOVA_API_KEY}`}:{})},body:JSON.stringify(payload)})}catch{}
}
function cleanCustomer(c={}){const keys=["first_name","last_name","email","phone","address","postal_code","city"];return Object.fromEntries(keys.map(k=>[k,String(c[k]||"").trim()]))}
function orderTotals(items=[],env){
 let subtotal=0,clean=[];
 for(const i of items){const p=PRODUCTS[i.slug];if(!p)continue;const qty=Math.max(1,Math.min(50,Number(i.qty)||1));subtotal+=p.price*qty;clean.push({slug:i.slug,name:p.name,unit_price:p.price,qty,options:String(i.options||"").slice(0,500)})}
 subtotal=Math.round(subtotal*100)/100;const threshold=Number(env.FREE_SHIPPING_THRESHOLD||49),shipping=subtotal>=threshold?0:Number(env.STANDARD_SHIPPING_PRICE||4.9);
 return {items:clean,subtotal,shipping,total:Math.round((subtotal+shipping)*100)/100}
}

function cookie(req,name){const raw=req.headers.get("cookie")||"";for(const part of raw.split(";")){const [k,...v]=part.trim().split("=");if(k===name)return decodeURIComponent(v.join("="))}return ""}
function b64url(bytes){return btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"")}
async function hmac(secret,text){const key=await crypto.subtle.importKey("raw",new TextEncoder().encode(secret),{name:"HMAC",hash:"SHA-256"},false,["sign"]);return b64url(await crypto.subtle.sign("HMAC",key,new TextEncoder().encode(text)))}
async function makeAdminToken(env){const payload=btoa(JSON.stringify({exp:Date.now()+30*24*60*60*1000})).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"");return `${payload}.${await hmac(env.ADMIN_SESSION_SECRET,payload)}`}
async function adminOK(req,env){if(!env.ADMIN_SESSION_SECRET)return false;const tok=cookie(req,"mstk_admin");if(!tok||!tok.includes("."))return false;const [payload,sig]=tok.split(".");if((await hmac(env.ADMIN_SESSION_SECRET,payload))!==sig)return false;try{const norm=payload.replace(/-/g,"+").replace(/_/g,"/");const data=JSON.parse(atob(norm));return data.exp>Date.now()}catch{return false}}
async function adminDashboard(env){
 if(!supabaseReady(env))throw new Error("Supabase n’est pas configuré.");
 const [orders,quotes,contacts,usersRaw]=await Promise.all([
   sb(env,"/rest/v1/orders?select=reference,email,total,status,created_at&order=created_at.desc&limit=20"),
   sb(env,"/rest/v1/quotes?select=reference,email,status,created_at&order=created_at.desc&limit=20"),
   sb(env,"/rest/v1/contacts?select=name,email,subject,status,created_at&order=created_at.desc&limit=20"),
   fetch(`${env.SUPABASE_URL}/auth/v1/admin/users?page=1&per_page=50`,{headers:{"apikey":env.SUPABASE_SERVICE_ROLE_KEY,"Authorization":`Bearer ${env.SUPABASE_SERVICE_ROLE_KEY}`}}).then(r=>r.json())
 ]);
 return {orders,quotes,contacts,clients:usersRaw.users||[]};
}
async function apiHandler(req,env,url){
 const p=url.pathname,method=req.method;
 try{
  if(p==="/api/health")return json({ok:true,service:"MSTKPRINT37 PRO",time:new Date().toISOString(),supabase:!!env.SUPABASE_URL,sumup:!!env.SUMUP_API_KEY,nova:!!env.NOVA_API_URL});
  if(p==="/api/admin/login"&&method==="POST"){if(!env.NOVA_ADMIN_PIN||!env.ADMIN_SESSION_SECRET)return json({error:"Configure NOVA_ADMIN_PIN et ADMIN_SESSION_SECRET dans les secrets Cloudflare."},503);const b=await body(req);if(String(b.pin||"")!==String(env.NOVA_ADMIN_PIN))return json({error:"PIN incorrect."},401);const token=await makeAdminToken(env);return json({ok:true},200,{"Set-Cookie":`mstk_admin=${token}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=2592000`})}
  if(p==="/api/admin/logout"&&method==="POST")return json({ok:true},200,{"Set-Cookie":"mstk_admin=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0"});
  if(p==="/api/admin/dashboard"&&method==="GET"){if(!(await adminOK(req,env)))return json({error:"Accès administrateur requis."},401);return json(await adminDashboard(env))}
  if(p==="/api/config")return json({site_name:env.SITE_NAME||"MSTKPRINT37",currency:env.CURRENCY||"EUR",free_shipping_threshold:Number(env.FREE_SHIPPING_THRESHOLD||49)});
  if(p==="/api/auth/signup"&&method==="POST"){if(!env.SUPABASE_URL||!env.SUPABASE_ANON_KEY)return json({error:"Supabase n’est pas encore configuré."},503);const b=await body(req);const data=await sb(env,"/auth/v1/signup",{method:"POST",payload:{email:b.email,password:b.password}});await nova(env,"client",{email:b.email,event:"signup"});return json({ok:true,user:data.user||null})}
  if(p==="/api/auth/login"&&method==="POST"){if(!env.SUPABASE_URL||!env.SUPABASE_ANON_KEY)return json({error:"Supabase n’est pas encore configuré."},503);const b=await body(req);const data=await sb(env,"/auth/v1/token?grant_type=password",{method:"POST",payload:{email:b.email,password:b.password}});return json(data)}
  if(p==="/api/account"&&method==="GET"){const t=bearer(req);if(!t)return json({error:"Connexion requise."},401);const data=await sb(env,"/auth/v1/user",{token:t});return json(data)}
  if(/^\/api\/account\/(orders|quotes|invoices)$/.test(p)&&method==="GET"){const t=bearer(req);if(!t)return json({error:"Connexion requise."},401);const type=p.split("/").pop();const user=await sb(env,"/auth/v1/user",{token:t});const rows=await sb(env,`/rest/v1/${type}?user_id=eq.${encodeURIComponent(user.id)}&select=*&order=created_at.desc`,{token:t});return json({items:rows})}
  if(p==="/api/contact"&&method==="POST"){const b=await body(req);if(!b.email||!b.message)return json({error:"E-mail et message requis."},400);const row={name:String(b.name||"").slice(0,120),email:String(b.email).slice(0,200),subject:String(b.subject||"").slice(0,200),message:String(b.message).slice(0,5000),status:"new"};if(supabaseReady(env))await sb(env,"/rest/v1/contacts",{method:"POST",payload:row,prefer:"return=minimal"});await nova(env,"contact",row);return json({ok:true,message:"Message enregistré. Nous revenons vers toi rapidement."})}
  if(p==="/api/quotes"&&method==="POST"){const b=await body(req);if(!b.email||!b.description)return json({error:"E-mail et description requis."},400);const ref=`DEV-${new Date().getFullYear()}-${crypto.randomUUID().slice(0,8).toUpperCase()}`;const row={reference:ref,name:String(b.name||"").slice(0,120),email:String(b.email).slice(0,200),object_type:String(b.object_type||"").slice(0,100),size:String(b.size||"").slice(0,50),color:String(b.color||"").slice(0,80),quantity:Math.max(1,Number(b.quantity)||1),custom_text:String(b.custom_text||"").slice(0,500),description:String(b.description).slice(0,5000),status:"requested"};if(supabaseReady(env))await sb(env,"/rest/v1/quotes",{method:"POST",payload:row,prefer:"return=minimal"});await nova(env,"quote",row);return json({ok:true,reference:ref,message:`Demande ${ref} enregistrée.`})}
  if(p==="/api/checkout/create"&&method==="POST"){
    const b=await body(req),customer=cleanCustomer(b.customer),tot=orderTotals(b.items,env);
    if(!customer.email||!customer.address||!tot.items.length)return json({error:"Commande incomplète."},400);
    const ref=`CMD-${new Date().getFullYear()}-${crypto.randomUUID().slice(0,8).toUpperCase()}`;
    let user_id=null;const t=bearer(req);if(t&&env.SUPABASE_URL){try{user_id=(await sb(env,"/auth/v1/user",{token:t})).id}catch{}}
    const row={reference:ref,user_id,email:customer.email,customer,items:tot.items,subtotal:tot.subtotal,shipping:tot.shipping,total:tot.total,currency:env.CURRENCY||"EUR",status:"awaiting_payment",payment_provider:"sumup"};
    if(supabaseReady(env))await sb(env,"/rest/v1/orders",{method:"POST",payload:row,prefer:"return=minimal"});
    await nova(env,"order",row);
    if(!env.SUMUP_API_KEY||!env.SUMUP_MERCHANT_CODE)return json({error:"La commande est prête, mais SumUp n’est pas encore configuré dans les secrets Cloudflare.",order_reference:ref},503);
    const origin=env.PUBLIC_SITE_URL||url.origin;
    const sr=await fetch("https://api.sumup.com/v0.1/checkouts",{method:"POST",headers:{"Authorization":`Bearer ${env.SUMUP_API_KEY}`,"Content-Type":"application/json"},body:JSON.stringify({checkout_reference:ref,amount:tot.total,currency:env.CURRENCY||"EUR",merchant_code:env.SUMUP_MERCHANT_CODE,description:`Commande ${ref} - MSTKPRINT37`,redirect_url:`${origin}/commande?payment=return&reference=${encodeURIComponent(ref)}`,hosted_checkout:{enabled:true}})});
    const sum=await sr.json().catch(()=>({}));if(!sr.ok)return json({error:sum.message||"Erreur SumUp",details:sum,order_reference:ref},502);
    if(supabaseReady(env))await sb(env,`/rest/v1/orders?reference=eq.${encodeURIComponent(ref)}`,{method:"PATCH",payload:{payment_checkout_id:sum.id},prefer:"return=minimal"});
    return json({ok:true,order_reference:ref,checkout_id:sum.id,checkout_url:sum.hosted_checkout_url});
  }
  if(p.startsWith("/api/sumup/status/")&&method==="GET"){if(!env.SUMUP_API_KEY)return json({error:"SumUp non configuré."},503);const id=p.split("/").pop();const r=await fetch(`https://api.sumup.com/v0.1/checkouts/${encodeURIComponent(id)}`,{headers:{"Authorization":`Bearer ${env.SUMUP_API_KEY}`}});const d=await r.json();return json(d,r.status)}
  if(p==="/api/track"&&method==="GET"){const ref=url.searchParams.get("reference"),email=url.searchParams.get("email");if(!ref||!email)return json({error:"Référence et e-mail requis."},400);if(!supabaseReady(env))return json({error:"Le suivi sera actif une fois Supabase configuré."},503);const rows=await sb(env,`/rest/v1/orders?reference=eq.${encodeURIComponent(ref)}&email=eq.${encodeURIComponent(email)}&select=reference,status,updated_at&limit=1`);if(!rows.length)return json({error:"Commande introuvable."},404);return json(rows[0])}
  return json({error:"API introuvable"},404);
 }catch(e){return json({error:e.message||"Erreur serveur"},500)}
}
function sitemap(origin){const paths=["/","/boutique","/nouveautes","/promotions","/personnaliser","/services","/galerie","/avis","/a-propos","/atelier","/faq","/contact","/livraison","/retours","/suivi",...Object.keys(PRODUCTS).map(s=>`/produit/${s}`)];return `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${paths.map(p=>`<url><loc>${origin}${p}</loc></url>`).join("")}</urlset>`}
export default {
 async fetch(req,env){
  const url=new URL(req.url),path=url.pathname.replace(/\/+$/,"")||"/";
  if(path.startsWith("/api/"))return apiHandler(req,env,new URL(url.origin+path+url.search));
  if(path==="/robots.txt")return new Response(`User-agent: *\nAllow: /\nSitemap: ${env.PUBLIC_SITE_URL||url.origin}/sitemap.xml\n`,{headers:{"content-type":"text/plain;charset=utf-8"}});
  if(path==="/sitemap.xml")return new Response(sitemap(env.PUBLIC_SITE_URL||url.origin),{headers:{"content-type":"application/xml;charset=utf-8"}});
  if(/\.[a-zA-Z0-9]+$/.test(path))return env.ASSETS.fetch(req);
  const html=pageContent(path);if(html)return new Response(html,{headers:{"content-type":"text/html;charset=utf-8","cache-control":"public, max-age=60"}});
  return new Response(pageShell(path,"Page introuvable",`<section class="pagehero"><div class="container"><h1>404</h1><p>Cette page n’existe pas.</p><a class="btn primary" href="/">Retour à l’accueil</a></div></section>`,"Page introuvable"),{status:404,headers:{"content-type":"text/html;charset=utf-8"}});
 }
}

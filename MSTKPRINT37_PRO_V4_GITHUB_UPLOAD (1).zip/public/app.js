const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
const money=n=>new Intl.NumberFormat('fr-FR',{style:'currency',currency:'EUR'}).format(Number(n||0));
const store={
  get cart(){try{return JSON.parse(localStorage.getItem('mstk_cart')||'[]')}catch{return[]}},
  set cart(v){localStorage.setItem('mstk_cart',JSON.stringify(v));updateCartBadge()},
  get token(){return localStorage.getItem('mstk_token')||''},
  set token(v){v?localStorage.setItem('mstk_token',v):localStorage.removeItem('mstk_token')}
};
function updateCartBadge(){const n=store.cart.reduce((a,b)=>a+(b.qty||1),0);$$('[data-cart-count]').forEach(e=>e.textContent=n)}
function toast(m){const t=$('#toast');if(!t)return;t.textContent=m;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2600)}
function addCart(p){const c=store.cart;const found=c.find(x=>x.slug===p.slug&&x.options===p.options);found?found.qty++:c.push({...p,qty:1});store.cart=c;toast('Ajouté au panier')}
window.MSTK={addCart,store,money,toast};

$$('[data-add]').forEach(b=>b.addEventListener('click',()=>addCart({
  slug:b.dataset.add,name:b.dataset.name,price:Number(b.dataset.price),icon:b.dataset.icon||'🧩',options:b.dataset.options||''
})));

$('#mobileToggle')?.addEventListener('click',()=>$('#navlinks')?.classList.toggle('open'));
$('#searchBtn')?.addEventListener('click',()=>{$('#searchBox')?.classList.add('show');setTimeout(()=>$('#siteSearch')?.focus(),60)});
$('#searchClose')?.addEventListener('click',()=>$('#searchBox')?.classList.remove('show'));
$('#siteSearch')?.addEventListener('input',e=>{
  const q=e.target.value.toLowerCase().trim(), out=$('#searchResults');
  const items=[
    ['Boutique','/boutique'],['Figurines personnalisées','/produit/figurine-personnalisee'],['Porte-clés','/produit/porte-cles-personnalise'],
    ['Décoration murale','/produit/deco-murale'],['Cadre photo LED','/produit/cadre-photo-led'],['Créer mon objet','/personnaliser'],
    ['Impression 3D sur mesure','/services'],['Suivre ma commande','/suivi'],['FAQ','/faq'],['Contact','/contact']
  ].filter(x=>x[0].toLowerCase().includes(q));
  out.innerHTML=q?items.map(x=>`<a href="${x[1]}">${x[0]}</a>`).join(''):'';
});
document.addEventListener('keydown',e=>{if(e.key==='Escape')$('#searchBox')?.classList.remove('show')});

const cookie=$('#cookieBanner');
if(cookie && !localStorage.getItem('mstk_cookie_choice')) cookie.classList.add('show');
$$('[data-cookie]').forEach(b=>b.addEventListener('click',()=>{localStorage.setItem('mstk_cookie_choice',b.dataset.cookie);cookie?.classList.remove('show');toast('Préférences enregistrées')}));

async function api(path,opts={}){
  const h={'Content-Type':'application/json',...(opts.headers||{})};
  if(store.token)h.Authorization=`Bearer ${store.token}`;
  const r=await fetch(path,{...opts,headers:h});
  const data=await r.json().catch(()=>({}));
  if(!r.ok)throw new Error(data.error||'Une erreur est survenue');
  return data;
}

$$('form[data-api]').forEach(f=>f.addEventListener('submit',async e=>{
  e.preventDefault(); const btn=$('button[type=submit]',f), old=btn?.textContent;
  try{
    if(btn){btn.disabled=true;btn.textContent='Envoi…'}
    const body=Object.fromEntries(new FormData(f).entries());
    const data=await api(f.dataset.api,{method:'POST',body:JSON.stringify(body)});
    toast(f.dataset.success||'C’est envoyé !'); f.reset();
    const out=$('[data-form-result]',f.parentElement);if(out)out.innerHTML=`<div class="notice success">${data.message||'Demande enregistrée.'}</div>`;
  }catch(err){toast(err.message)}
  finally{if(btn){btn.disabled=false;btn.textContent=old}}
}));

$('#loginForm')?.addEventListener('submit',async e=>{
  e.preventDefault();const body=Object.fromEntries(new FormData(e.currentTarget).entries());
  try{const r=await api('/api/auth/login',{method:'POST',body:JSON.stringify(body)});store.token=r.access_token;toast('Connexion réussie');location.href='/compte'}
  catch(err){toast(err.message)}
});
$('#signupForm')?.addEventListener('submit',async e=>{
  e.preventDefault();const body=Object.fromEntries(new FormData(e.currentTarget).entries());
  try{await api('/api/auth/signup',{method:'POST',body:JSON.stringify(body)});toast('Compte créé. Vérifie ton e-mail si demandé.')}
  catch(err){toast(err.message)}
});
$('[data-logout]')?.addEventListener('click',()=>{store.token='';toast('Déconnecté');setTimeout(()=>location.href='/',500)});

function renderCart(){
  const root=$('#cartItems'), sum=$('#cartSummary');if(!root||!sum)return;
  const c=store.cart;
  if(!c.length){root.innerHTML='<div class="empty">Ton panier est vide.<br><a class="btn primary" href="/boutique" style="margin-top:16px">Voir la boutique</a></div>';sum.innerHTML='';return}
  root.innerHTML=c.map((x,i)=>`<div class="cart-row"><div class="cart-img">${x.icon}</div><div><b>${x.name}</b><div class="muted small">${x.options||'Fabrication à la demande'}</div><button class="btn ghost small" data-remove="${i}">Retirer</button></div><div class="qty"><button data-q="${i},-1">−</button><b>${x.qty}</b><button data-q="${i},1">+</button></div><b>${money(x.price*x.qty)}</b></div>`).join('');
  const subtotal=c.reduce((a,x)=>a+x.price*x.qty,0), ship=subtotal>=49?0:4.9,total=subtotal+ship;
  sum.innerHTML=`<div class="card summary"><h3>Récapitulatif</h3><p>Sous-total <b style="float:right">${money(subtotal)}</b></p><p>Livraison <b style="float:right">${ship?money(ship):'Offerte'}</b></p><hr><p style="font-size:20px">Total <b style="float:right">${money(total)}</b></p><a class="btn primary full" href="/commande">Passer commande</a><p class="muted small">Paiement sécurisé via SumUp.</p></div>`;
  $$('[data-remove]').forEach(b=>b.onclick=()=>{const c=store.cart;c.splice(+b.dataset.remove,1);store.cart=c;renderCart()});
  $$('[data-q]').forEach(b=>b.onclick=()=>{let [i,d]=b.dataset.q.split(',').map(Number);const c=store.cart;c[i].qty=Math.max(1,c[i].qty+d);store.cart=c;renderCart()});
}
renderCart();

function renderCheckout(){
 const list=$('#checkoutList'); if(!list)return;
 const c=store.cart;if(!c.length){list.innerHTML='<div class="notice">Ton panier est vide.</div>';return}
 const subtotal=c.reduce((a,x)=>a+x.price*x.qty,0),ship=subtotal>=49?0:4.9,total=subtotal+ship;
 list.innerHTML=c.map(x=>`<p>${x.qty} × ${x.name}<b style="float:right">${money(x.qty*x.price)}</b></p>`).join('')+`<hr><p>Livraison<b style="float:right">${ship?money(ship):'Offerte'}</b></p><p style="font-size:20px">Total<b style="float:right">${money(total)}</b></p>`;
 $('#checkoutForm')?.addEventListener('submit',async e=>{
   e.preventDefault();const btn=$('button[type=submit]',e.currentTarget),old=btn.textContent;
   try{
     btn.disabled=true;btn.textContent='Création du paiement…';
     const customer=Object.fromEntries(new FormData(e.currentTarget).entries());
     const r=await api('/api/checkout/create',{method:'POST',body:JSON.stringify({items:c,customer})});
     if(r.checkout_url){localStorage.setItem('mstk_last_order',r.order_reference);location.href=r.checkout_url}
     else throw new Error('Lien de paiement indisponible');
   }catch(err){toast(err.message);btn.disabled=false;btn.textContent=old}
 });
}
renderCheckout();

$('#customizerForm')?.addEventListener('input',e=>{
 const f=e.currentTarget, qty=Number(f.quantity.value||1), base=Number(f.object_type.selectedOptions[0]?.dataset.price||7.9), size=Number(f.size.selectedOptions[0]?.dataset.factor||1);
 const estimate=base*size*qty;$('#estimate').textContent=money(estimate);
});
$('#customizerForm')?.dispatchEvent(new Event('input'));

$('#trackForm')?.addEventListener('submit',async e=>{
 e.preventDefault();const fd=new FormData(e.currentTarget);
 try{const r=await api(`/api/track?reference=${encodeURIComponent(fd.get('reference'))}&email=${encodeURIComponent(fd.get('email'))}`);$('#trackResult').innerHTML=`<div class="notice success"><b>${r.reference}</b><br>Statut : ${r.status}<br>Mis à jour : ${new Date(r.updated_at).toLocaleString('fr-FR')}</div>`}
 catch(err){$('#trackResult').innerHTML=`<div class="notice danger">${err.message}</div>`}
});

async function loadAccount(){
 const target=$('#accountData');if(!target)return;
 if(!store.token){target.innerHTML='<div class="notice">Connecte-toi pour voir tes informations.</div>';return}
 try{const r=await api('/api/account');target.innerHTML=`<div class="card"><span class="tag">Compte client</span><h3>${r.email||'Client MSTKPRINT37'}</h3><p>ID client : <span class="muted">${r.id}</span></p></div>`}
 catch(err){target.innerHTML=`<div class="notice danger">${err.message}</div>`}
}
loadAccount();

async function loadAccountList(){
 const target=$('[data-account-list]');if(!target)return;
 if(!store.token){target.innerHTML='<div class="notice">Connecte-toi pour accéder à cette rubrique.</div>';return}
 try{const type=target.dataset.accountList;const r=await api(`/api/account/${type}`);const rows=r.items||[];
   if(!rows.length){target.innerHTML='<div class="empty">Aucun élément pour le moment.</div>';return}
   target.innerHTML=`<div class="tablewrap"><table class="table"><thead><tr><th>Référence</th><th>Date</th><th>Statut</th><th>Total</th></tr></thead><tbody>${rows.map(x=>`<tr><td>${x.reference||x.id}</td><td>${new Date(x.created_at).toLocaleDateString('fr-FR')}</td><td>${x.status||'En cours'}</td><td>${x.total?money(x.total):'—'}</td></tr>`).join('')}</tbody></table></div>`
 }catch(err){target.innerHTML=`<div class="notice danger">${err.message}</div>`}
}
loadAccountList();
updateCartBadge();

async function renderNova(data){
 const root=$('#novaRoot');if(!root)return;
 const row=(x,kind)=>`<tr><td>${x.reference||x.name||x.email||'—'}</td><td>${x.email||'—'}</td><td>${x.status||kind}</td><td>${x.total?money(x.total):new Date(x.created_at||Date.now()).toLocaleDateString('fr-FR')}</td></tr>`;
 root.innerHTML=`<div class="section-head"><div><span class="eyebrow">NØVA ONLINE</span><h2>Tableau de bord</h2></div><button class="btn" id="novaLogout">Se déconnecter</button></div>
 <div class="grid cols-4"><div class="card"><span class="muted">Commandes récentes</span><h2>${data.orders.length}</h2></div><div class="card"><span class="muted">Devis récents</span><h2>${data.quotes.length}</h2></div><div class="card"><span class="muted">Contacts récents</span><h2>${data.contacts.length}</h2></div><div class="card"><span class="muted">Clients chargés</span><h2>${data.clients.length}</h2></div></div>
 <div class="card" style="margin-top:18px"><h3>Dernières commandes</h3><div class="tablewrap"><table class="table"><thead><tr><th>Référence</th><th>Client</th><th>Statut</th><th>Total</th></tr></thead><tbody>${data.orders.map(x=>row(x,'commande')).join('')||'<tr><td colspan="4">Aucune commande</td></tr>'}</tbody></table></div></div>
 <div class="grid cols-2" style="margin-top:18px"><div class="card"><h3>Derniers devis</h3><div class="tablewrap"><table class="table"><tbody>${data.quotes.map(x=>row(x,'devis')).join('')||'<tr><td>Aucun devis</td></tr>'}</tbody></table></div></div><div class="card"><h3>Derniers messages</h3><div class="tablewrap"><table class="table"><tbody>${data.contacts.map(x=>row(x,'contact')).join('')||'<tr><td>Aucun message</td></tr>'}</tbody></table></div></div></div>`;
 $('#novaLogout').onclick=async()=>{await api('/api/admin/logout',{method:'POST',body:'{}'});location.reload()};
}
async function loadNova(){
 if(!$('#novaRoot'))return;
 try{renderNova(await api('/api/admin/dashboard'))}catch{}
 $('#novaLogin')?.addEventListener('submit',async e=>{e.preventDefault();try{await api('/api/admin/login',{method:'POST',body:JSON.stringify(Object.fromEntries(new FormData(e.currentTarget).entries()))});renderNova(await api('/api/admin/dashboard'))}catch(err){$('#novaLoginMessage').innerHTML=`<div class="notice danger">${err.message}</div>`}});
}
loadNova();

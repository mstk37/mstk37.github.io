# MSTKPRINT37 PRO — Cloudflare

Refonte complète pensée pour Cloudflare Workers + Static Assets.

## Inclus

- Accueil professionnel et responsive
- Boutique + 6 produits de départ
- Fiches produit
- Panier persistant
- Checkout SumUp hébergé
- Personnalisation / demande de devis
- Espace client Supabase Auth
- Commandes / devis / factures
- Suivi de commande
- Contact
- Galerie, avis, FAQ, atelier, services
- Livraison et retours
- Mentions légales, CGV, confidentialité, cookies, médiation
- robots.txt + sitemap.xml
- API Worker
- Console NØVA privée par PIN (session 30 jours)
- Connecteur optionnel NØVA
- Base SQL Supabase
- Responsive iPhone / mobile

## 1 — Installer

```bash
npm install
```

## 2 — Tester sans clés

```bash
npm run dev
```

Le front est visible immédiatement. Les fonctions nécessitant Supabase/SumUp afficheront un message de configuration.

## 3 — Supabase

Dans Supabase > SQL Editor, exécute `SUPABASE_SCHEMA.sql`.

Puis récupère :
- Project URL
- anon/public key
- service_role key

La `service_role` ne doit JAMAIS être mise dans le navigateur ou dans un fichier public.

## 4 — Secrets Cloudflare

En production :

```bash
npx wrangler secret put SUPABASE_URL
npx wrangler secret put SUPABASE_ANON_KEY
npx wrangler secret put SUPABASE_SERVICE_ROLE_KEY
npx wrangler secret put SUMUP_API_KEY
npx wrangler secret put SUMUP_MERCHANT_CODE
npx wrangler secret put NOVA_ADMIN_PIN
npx wrangler secret put ADMIN_SESSION_SECRET
```

Optionnel pour NØVA :

```bash
npx wrangler secret put NOVA_API_URL
npx wrangler secret put NOVA_API_KEY
```

En local, copie `.dev.vars.example` vers `.dev.vars`.

## 5 — Déployer

```bash
npm run deploy
```

Puis, dans Cloudflare, ajoute le domaine personnalisé `mstkprint37.com` à ce Worker si nécessaire.

## NØVA

Si `NOVA_API_URL` est configurée, le Worker essaie d’envoyer :
- nouveau compte -> `POST /clients`
- nouvelle commande -> `POST /orders`
- nouveau devis -> `POST /quotes`
- nouveau contact -> `POST /contacts`

Adapte uniquement la fonction `nova()` dans `src/index.js` si tes routes NØVA actuelles ont d’autres noms.

## SumUp

Le Worker crée un checkout SumUp côté serveur et demande un Hosted Checkout. Le navigateur ne voit jamais la clé API.

## À personnaliser avant mise en production

1. Remplacer/compléter les mentions légales (SIREN/SIRET, e-mail, directeur de publication, médiateur).
2. Faire relire les CGV / politique de confidentialité si nécessaire.
3. Mettre tes vraies photos produits.
4. Modifier les produits/prix dans `PRODUCTS` au début de `src/index.js`.
5. Relier Supabase Storage si tu veux permettre l’upload de photos/fichiers STL.
6. Adapter la fonction `nova()` aux endpoints exacts de ton NØVA existant.
7. Ajouter la logique de vérification automatique du statut SumUp si tu veux basculer `awaiting_payment` vers `paid` sans action manuelle.

## Console NØVA

Ouvre `/nova`. Le PIN est défini dans le secret `NOVA_ADMIN_PIN`. La session signée utilise `ADMIN_SESSION_SECRET` et reste dans un cookie HttpOnly pendant 30 jours.

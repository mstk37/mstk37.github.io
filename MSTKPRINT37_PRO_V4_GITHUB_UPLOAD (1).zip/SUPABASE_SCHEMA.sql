-- MSTKPRINT37 PRO — Supabase
-- À exécuter dans Supabase > SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  reference text unique not null,
  user_id uuid null references auth.users(id) on delete set null,
  email text not null,
  customer jsonb not null default '{}'::jsonb,
  items jsonb not null default '[]'::jsonb,
  subtotal numeric(10,2) not null default 0,
  shipping numeric(10,2) not null default 0,
  total numeric(10,2) not null default 0,
  currency text not null default 'EUR',
  status text not null default 'awaiting_payment',
  payment_provider text,
  payment_checkout_id text,
  tracking_number text,
  tracking_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.quotes (
  id uuid primary key default gen_random_uuid(),
  reference text unique not null,
  user_id uuid null references auth.users(id) on delete set null,
  name text,
  email text not null,
  object_type text,
  size text,
  color text,
  quantity integer not null default 1,
  custom_text text,
  description text,
  status text not null default 'requested',
  total numeric(10,2),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.invoices (
  id uuid primary key default gen_random_uuid(),
  reference text unique not null,
  user_id uuid null references auth.users(id) on delete set null,
  order_id uuid null references public.orders(id) on delete set null,
  email text,
  total numeric(10,2),
  status text not null default 'issued',
  pdf_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.contacts (
  id uuid primary key default gen_random_uuid(),
  name text,
  email text not null,
  subject text,
  message text not null,
  status text not null default 'new',
  created_at timestamptz not null default now()
);

alter table public.orders enable row level security;
alter table public.quotes enable row level security;
alter table public.invoices enable row level security;
alter table public.contacts enable row level security;

drop policy if exists "users read own orders" on public.orders;
create policy "users read own orders" on public.orders for select to authenticated using (auth.uid() = user_id);

drop policy if exists "users read own quotes" on public.quotes;
create policy "users read own quotes" on public.quotes for select to authenticated using (auth.uid() = user_id);

drop policy if exists "users read own invoices" on public.invoices;
create policy "users read own invoices" on public.invoices for select to authenticated using (auth.uid() = user_id);

create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

drop trigger if exists orders_touch_updated_at on public.orders;
create trigger orders_touch_updated_at before update on public.orders for each row execute function public.touch_updated_at();

drop trigger if exists quotes_touch_updated_at on public.quotes;
create trigger quotes_touch_updated_at before update on public.quotes for each row execute function public.touch_updated_at();

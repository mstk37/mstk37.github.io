
/* =========================================================
   MSTKPRINT37 — Commandes + Supabase + SumUp
   ========================================================= */
const ORDER_API = "https://ommcthgvikaphurayxax.supabase.co/functions/v1/mstk-order-intake-v12";
const CART_KEY = "mstk_cart_v2";
const OLD_CART_KEY = "mstk_cart_v1";
const LAST_ORDER_KEY = "mstk_last_order_v1";
const MANUAL_COUPON_KEY = "mstk_coupon_manual_v1";
const LUCKY_RESULT_STORAGE = "mstk_lucky_nozzle_result_v1";

// ===== CHRONOPOST SHOP2SHOP (MODE MANUEL) =====
let selectedDeliveryType = "pickup_store";
let currentShippingQuote = null;
let currentShippingWeight = 0;

const PRODUCT_SLUGS = {
  "fig-1":"crabby-le-crabe",
  "fig-2":"bunny-le-lapin",
  "fig-3":"buddy-le-chiot",
  "fig-4":"ducky-le-caneton",
  "fig-5":"gator-alligator",
  "fig-6":"rudy-le-renne",
  "fig-7":"wooly-le-mouton",
  "fig-8":"froppy-la-grenouille",
  "fig-9":"foxy-le-renard",
  "fig-10":"bananou-la-banane",
  "fig-11":"hippo-hippopotame",
  "fig-12":"piggy-le-cochon",
  "fig-13":"dino-le-dino",
  "fig-14":"splash-le-dauphin",
  "fig-15":"flamy-le-flamant"
};

function money(n){
  return Number(n || 0).toLocaleString("fr-FR", {style:"currency", currency:"EUR"});
}

function escapeHTML(value){
  return String(value ?? "").replace(/[&<>"']/g, c => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[c]));
}

function migrateCart(){
  if(localStorage.getItem(CART_KEY)) return;
  try{
    const old = JSON.parse(localStorage.getItem(OLD_CART_KEY) || "[]");
    if(Array.isArray(old) && old.length){
      old.forEach(i => { if(!i.slug && PRODUCT_SLUGS[i.id]) i.slug = PRODUCT_SLUGS[i.id]; });
      localStorage.setItem(CART_KEY, JSON.stringify(old));
    }
  }catch(e){}
}

function getCart(){
  migrateCart();
  try{
    const cart = JSON.parse(localStorage.getItem(CART_KEY) || "[]");
    return Array.isArray(cart) ? cart : [];
  }catch{
    return [];
  }
}

function saveCart(cart){
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
  updateCartCount();
}

function updateCartCount(){
  const n = getCart().reduce((s,i) => s + (Number(i.qty) || 1), 0);
  document.querySelectorAll("[data-cart-count]").forEach(el => el.textContent = n);
}

function addToCart(id, name, price, slug=null){
  const cart = getCart();
  const item = cart.find(i => i.id === id);
  const finalSlug = slug || PRODUCT_SLUGS[id] || null;
  if(item){
    item.qty = (Number(item.qty) || 1) + 1;
    if(finalSlug) item.slug = finalSlug;
  }else{
    cart.push({id, name, price:Number(price), qty:1, slug:finalSlug});
  }
  saveCart(cart);
  alert(name + " ajouté au panier.");
}

function setQty(id, delta){
  const cart = getCart();
  const item = cart.find(i => i.id === id);
  if(!item) return;
  item.qty = Math.max(0, (Number(item.qty) || 1) + delta);
  saveCart(cart.filter(i => i.qty > 0));
  renderCart();
  renderCheckoutSummary();
}

function removeFromCart(id){
  saveCart(getCart().filter(i => i.id !== id));
  renderCart();
  renderCheckoutSummary();
}

function getSavedCoupon(){
  try{
    const p = JSON.parse(localStorage.getItem(LUCKY_RESULT_STORAGE) || "null");
    return p && p.code ? String(p.code).toUpperCase() : "";
  }catch{
    return "";
  }
}

function getManualCoupon(){
  return String(localStorage.getItem(MANUAL_COUPON_KEY) || "").trim().toUpperCase();
}

function activeCoupon(){
  return getManualCoupon() || getSavedCoupon();
}

function couponValue(code, afterPromo){
  code = String(code || "").toUpperCase();
  if(code === "BUSE1" && afterPromo >= 6) return 1;
  if(code === "BUSE2" && afterPromo >= 12) return 2;
  if(code === "BUSE5" && afterPromo >= 10) return +(afterPromo * .05).toFixed(2);
  if(code === "BUSE10" && afterPromo >= 15) return +(afterPromo * .10).toFixed(2);
  return 0;
}

function cartTotals(){
  const cart = getCart();
  const subtotal = cart.reduce((s,i) => s + (Number(i.price)||0) * (Number(i.qty)||1), 0);

  const eligible = [];
  cart.forEach(i => {
    if(PRODUCT_SLUGS[i.id] || String(i.slug || "").includes("-")){
      if(String(i.id || "").startsWith("fig-")){
        for(let q=0; q<(Number(i.qty)||1); q++) eligible.push(Number(i.price)||0);
      }
    }
  });
  eligible.sort((a,b)=>a-b);
  const freeCount = Math.floor(eligible.length / 5);
  const promo = eligible.slice(0, freeCount).reduce((a,b)=>a+b, 0);

  const afterPromo = Math.max(0, subtotal - promo);
  const coupon = activeCoupon();
  const couponDiscount = Math.min(afterPromo, couponValue(coupon, afterPromo));
  const total = Math.max(0, afterPromo - couponDiscount);

  return {
    subtotal:+subtotal.toFixed(2),
    promo:+promo.toFixed(2),
    coupon,
    couponDiscount:+couponDiscount.toFixed(2),
    total:+total.toFixed(2),
    eligibleCount:eligible.length
  };
}

function couponMessage(t){
  if(!t.coupon) return "Aucun code La Buse Chanceuse appliqué.";
  if(t.coupon === "BUSEPORT") return "Code BUSEPORT enregistré. Les frais de livraison sont actuellement à 0 € sur cette version.";
  if(t.couponDiscount > 0) return `Code ${t.coupon} appliqué : -${money(t.couponDiscount)}.`;
  return `Code ${t.coupon} détecté, mais le minimum de commande n'est pas encore atteint.`;
}

function applyCoupon(){
  const input = document.querySelector("#couponInput");
  if(!input) return;
  const code = String(input.value || "").trim().toUpperCase();
  if(code) localStorage.setItem(MANUAL_COUPON_KEY, code);
  else localStorage.removeItem(MANUAL_COUPON_KEY);
  renderCart();
  renderCheckoutSummary();
}

function renderCart(){
  const root = document.querySelector("#cart-root");
  if(!root) return;
  const cart = getCart();

  if(!cart.length){
    root.innerHTML = `
      <div class="empty">
        Ton panier est vide pour le moment.<br><br>
        <a class="btn" href="catalogue.html">Voir le catalogue</a>
      </div>`;
    return;
  }

  const rows = cart.map(i => {
    const line = (Number(i.price)||0) * (Number(i.qty)||1);
    return `<div class="card cart-line">
      <div>
        <strong>${escapeHTML(i.name)}</strong>
        <div class="muted">${money(i.price)} l'unité</div>
      </div>
      <div class="qty-control">
        <button type="button" onclick="setQty('${escapeHTML(i.id)}',-1)">−</button>
        <strong>${Number(i.qty)||1}</strong>
        <button type="button" onclick="setQty('${escapeHTML(i.id)}',1)">+</button>
      </div>
      <div class="cart-line-total">${money(line)}</div>
      <button class="btn secondary" type="button" onclick="removeFromCart('${escapeHTML(i.id)}')">Retirer</button>
    </div>`;
  }).join("");

  const t = cartTotals();
  root.innerHTML = rows + `
    <div class="checkout-layout">
      <div class="card">
        <h3>🎁 La Buse Chanceuse</h3>
        <div class="coupon-entry">
          <input id="couponInput" value="${escapeHTML(activeCoupon())}" placeholder="Ex. BUSE1">
          <button class="btn secondary" type="button" onclick="applyCoupon()">Appliquer</button>
        </div>
        <p class="muted small">${escapeHTML(couponMessage(t))}</p>
        <p class="muted small">${t.eligibleCount} figurine(s) éligible(s) à l'offre 4 + 1.</p>
      </div>

      <div class="card order-summary">
        <h3>Récapitulatif</h3>
        <div class="summary-row"><span>Sous-total</span><strong>${money(t.subtotal)}</strong></div>
        ${t.promo>0 ? `<div class="summary-row saving"><span>Offre 4 + 1</span><strong>− ${money(t.promo)}</strong></div>` : ""}
        ${t.couponDiscount>0 ? `<div class="summary-row saving"><span>${escapeHTML(t.coupon)}</span><strong>− ${money(t.couponDiscount)}</strong></div>` : ""}
        <div class="summary-row total"><span>Total</span><strong>${money(t.total)}</strong></div>
        <a class="btn sumup-btn" href="commande.html">Payer avec SumUp →</a>
        <div class="secure-payment-note">🔒 Paiement sécurisé sur la page officielle SumUp</div>
      </div>
    </div>`;
}

function effectiveShippingPrice(){
  if(selectedDeliveryType !== "chronopost_shop2shop" || !currentShippingQuote) return 0;
  const t = cartTotals();
  if(String(t.coupon || "").toUpperCase() === "BUSEPORT" && (t.subtotal - t.promo) >= 20) return 0;
  return Number(currentShippingQuote.price || 0);
}

function renderCheckoutSummary(){
  const root = document.querySelector("#checkout-summary");
  if(!root) return;
  const cart = getCart();
  const submit = document.querySelector("#orderSubmit");

  if(!cart.length){
    root.innerHTML = '<div class="empty">Ton panier est vide. <a href="catalogue.html">Retour au catalogue</a></div>';
    if(submit) submit.disabled = true;
    return;
  }

  const t = cartTotals();
  const shipping = effectiveShippingPrice();
  const finalTotal = +(t.total + shipping).toFixed(2);
  const shippingLabel = selectedDeliveryType === "pickup_store"
    ? "Retrait atelier"
    : "Shop2Shop Chronopost — relais Pickup";

  if(submit){
    submit.disabled = selectedDeliveryType === "chronopost_shop2shop" && !currentShippingQuote;
  }

  root.innerHTML = `
    ${cart.map(i => `<div class="summary-row"><span>${Number(i.qty)||1} × ${escapeHTML(i.name)}</span><strong>${money((Number(i.price)||0)*(Number(i.qty)||1))}</strong></div>`).join("")}
    <hr class="soft-line">
    <div class="summary-row"><span>Sous-total</span><strong>${money(t.subtotal)}</strong></div>
    ${t.promo>0 ? `<div class="summary-row saving"><span>Offre 4 + 1</span><strong>− ${money(t.promo)}</strong></div>` : ""}
    ${t.couponDiscount>0 ? `<div class="summary-row saving"><span>${escapeHTML(t.coupon)}</span><strong>− ${money(t.couponDiscount)}</strong></div>` : ""}
    <div class="summary-row"><span>${escapeHTML(shippingLabel)}</span><strong>${selectedDeliveryType === "chronopost_shop2shop" && !currentShippingQuote ? "À calculer" : money(shipping)}</strong></div>
    ${currentShippingWeight ? `<div class="muted small">Poids colis calculé : ${(currentShippingWeight/1000).toFixed(3).replace('.',',')} kg</div>` : ""}
    <div class="summary-row total"><span>Total à payer</span><strong>${money(finalTotal)}</strong></div>
    <p class="muted small">${escapeHTML(couponMessage(t))}</p>
    <div class="sumup-trust">📦 Livraison Shop2Shop Chronopost · 💳 paiement traité par SumUp</div>`;
}

function deliveryTypeChanged(value){
  selectedDeliveryType = value === "chronopost_shop2shop" ? value : "pickup_store";
  currentShippingQuote = null;
  currentShippingWeight = 0;
  const box = document.getElementById("chronopostBox");
  if(box) box.hidden = selectedDeliveryType !== "chronopost_shop2shop";
  const status = document.getElementById("shippingStatus");
  if(status){ status.className='order-status'; status.textContent=''; }
  renderCheckoutSummary();
  document.querySelectorAll('.delivery-choice').forEach(label => {
    const radio = label.querySelector('input[type="radio"]');
    label.classList.toggle('selected', !!radio?.checked);
  });
  if(selectedDeliveryType === "chronopost_shop2shop") quoteChronopostShipping();
}

function checkoutItems(){
  return getCart().map(i => ({
    slug:i.slug || PRODUCT_SLUGS[i.id] || null,
    quantity:Number(i.qty)||1
  }));
}

async function quoteChronopostShipping(){
  const status = document.getElementById('shippingStatus');
  if(selectedDeliveryType !== 'chronopost_shop2shop') return;
  if(status){ status.className='order-status'; status.innerHTML='<strong>Calcul du tarif Shop2Shop selon le poids…</strong>'; }
  try{
    const data = await apiPost({ action:'shipping_quote', delivery_type:'chronopost_shop2shop', items:checkoutItems() });
    currentShippingWeight = Number(data.weight_grams || 0);
    currentShippingQuote = {
      price:Number(data.shipping || 0),
      method:String(data.shipping_method || 'Shop2Shop Chronopost — relais Pickup')
    };
    if(status){
      status.className='order-status success';
      status.innerHTML=`<strong>✅ ${escapeHTML(currentShippingQuote.method)}</strong><p>${(currentShippingWeight/1000).toFixed(3).replace('.',',')} kg · ${money(effectiveShippingPrice())}</p>`;
    }
  }catch(err){
    currentShippingQuote = null;
    currentShippingWeight = 0;
    if(status){ status.className='order-status error'; status.textContent=err?.message || 'Impossible de calculer la livraison Chronopost.'; }
  }
  renderCheckoutSummary();
}

async function apiPost(payload){
  const res = await fetch(ORDER_API, {
    method:"POST",
    headers:{"content-type":"application/json"},
    body:JSON.stringify(payload),
    cache:"no-store"
  });
  const data = await res.json().catch(()=>({}));
  if(!res.ok || data.ok === false){
    throw new Error(data.error || "Une erreur est survenue.");
  }
  return data;
}

function rememberOrder(orderNumber, email, total, paymentUrl=""){
  const value = {
    order_number:orderNumber,
    customer_email:String(email||"").toLowerCase(),
    total:Number(total||0),
    payment_url:paymentUrl || "",
    saved_at:Date.now()
  };
  localStorage.setItem(LAST_ORDER_KEY, JSON.stringify(value));
  return value;
}

function getRememberedOrder(){
  try{
    return JSON.parse(localStorage.getItem(LAST_ORDER_KEY) || "null");
  }catch{
    return null;
  }
}

async function placeOrder(ev){
  ev.preventDefault();
  const form = ev.currentTarget;
  const submit = document.querySelector("#orderSubmit");
  const status = document.querySelector("#orderStatus");
  const cart = getCart();
  if(!cart.length) return;

  const fd = new FormData(form);
  if(fd.get("website")) return;

  const deliveryType = String(fd.get('delivery_type') || selectedDeliveryType || 'pickup_store');
  const pickupRelay = String(fd.get('pickup_relay') || '').trim();
  if(deliveryType === 'chronopost_shop2shop' && !currentShippingQuote){
    if(status){
      status.className='order-status warning';
      status.textContent='Calcule d’abord les frais de livraison Chronopost.';
    }
    return;
  }
  if(deliveryType === 'chronopost_shop2shop' && pickupRelay.length < 3){
    if(status){
      status.className='order-status warning';
      status.textContent='Indique le relais Pickup choisi avant de payer.';
    }
    return;
  }

  const payload = {
    customer_name:String(fd.get("customer_name")||"").trim(),
    customer_email:String(fd.get("customer_email")||"").trim(),
    customer_phone:String(fd.get("customer_phone")||"").trim(),
    address:String(fd.get("address")||"").trim(),
    postal_code:String(fd.get("postal_code")||"").trim(),
    city:String(fd.get("city")||"").trim(),
    notes:String(fd.get("notes")||"").trim(),
    coupon_code:activeCoupon(),
    source:"mstkprint37",
    delivery_type:deliveryType,
    pickup_relay:pickupRelay || null,
    service_point:pickupRelay ? { name:pickupRelay } : null,
    shipping_option_code:deliveryType === 'chronopost_shop2shop' ? 'shop2shop_manual' : null,
    items:cart.map(i => ({
      slug:i.slug || PRODUCT_SLUGS[i.id] || null,
      name:i.name,
      quantity:Number(i.qty)||1,
      unit_price:Number(i.price)||0
    }))
  };

  if(submit){ submit.disabled=true; submit.textContent="Création de la commande…"; }
  if(status){
    status.className="order-status";
    status.innerHTML='<strong>Connexion à MSTKPRINT37…</strong><p>Vérification du panier, du tarif Chronopost et préparation du paiement SumUp.</p>';
  }

  try{
    const data = await apiPost(payload);
    rememberOrder(data.order_number, payload.customer_email, data.total, data.payment_url || "");
    localStorage.removeItem(CART_KEY);
    localStorage.removeItem(OLD_CART_KEY);
    localStorage.removeItem(MANUAL_COUPON_KEY);
    updateCartCount();

    if(data.payment_url){
      if(status){
        status.className="order-status success";
        status.innerHTML = `<strong>✅ Commande ${escapeHTML(data.order_number)} enregistrée</strong>
          <p>Livraison : <strong>${escapeHTML(data.shipping_method || 'Retrait atelier')}</strong>${data.shipping ? ` — ${money(data.shipping)}` : ''}</p>
          <p>Total : <strong>${money(data.total)}</strong></p>
          <p>Ouverture de la page sécurisée SumUp…</p>`;
      }
      if(submit) submit.textContent="Ouverture de SumUp…";
      setTimeout(() => window.location.assign(data.payment_url), 450);
      return;
    }

    if(status){
      status.className="order-status warning";
      status.innerHTML = `<strong>✅ Commande ${escapeHTML(data.order_number)} enregistrée</strong>
        <p>Total : <strong>${money(data.total)}</strong></p>
        <p>Le paiement SumUp n'a pas pu être créé automatiquement pour le moment.</p>
        <button class="btn sumup-btn" type="button" onclick="retryPayment('${escapeHTML(data.order_number)}','${escapeHTML(payload.customer_email)}')">Réessayer le paiement SumUp</button>
        ${data.payment_error ? `<p class="muted small">${escapeHTML(data.payment_error)}</p>` : ""}`;
    }
    if(submit){ submit.disabled=false; submit.textContent="Réessayer"; }
  }catch(err){
    if(status){ status.className="order-status error"; status.textContent=err?.message || "Impossible de créer la commande."; }
    if(submit){ submit.disabled=false; submit.textContent="Payer avec SumUp"; }
  }
}

async function retryPayment(orderNumber, email){
  const status = document.querySelector("#orderStatus") || document.querySelector("#trackingResult");
  if(status){
    status.className = "order-status";
    status.innerHTML = "<strong>Création d'un nouveau lien SumUp…</strong>";
  }
  try{
    const data = await apiPost({
      action:"retry_payment",
      order_number:orderNumber,
      customer_email:email
    });
    if(data.payment_url){
      rememberOrder(orderNumber, email, data.total, data.payment_url);
      window.location.assign(data.payment_url);
      return;
    }
    throw new Error(data.payment_error || "Le paiement SumUp n'est pas disponible.");
  }catch(err){
    if(status){
      status.className = "order-status error";
      status.textContent = err?.message || "Impossible de créer le paiement.";
    }
  }
}

function statusLabel(payment){
  const map = {
    paid:"Payé",
    pending:"En attente",
    unpaid:"Non payé",
    failed:"Échec",
    refunded:"Remboursé"
  };
  return map[payment] || payment || "Inconnu";
}

function orderStatusLabel(status){
  const map = {
    pending:"Nouvelle",
    confirmed:"Confirmée",
    production:"En production",
    shipped:"Expédiée",
    completed:"Terminée",
    cancelled:"Annulée"
  };
  return map[status] || status || "Nouvelle";
}

async function checkOrderStatus(orderNumber, email, targetId="trackingResult"){
  const target = document.getElementById(targetId);
  if(!target) return;
  target.className = "order-status";
  target.innerHTML = "<strong>Vérification de la commande…</strong>";

  try{
    const data = await apiPost({
      action:"status",
      order_number:String(orderNumber||"").trim(),
      customer_email:String(email||"").trim()
    });

    const paid = data.payment_status === "paid";
    const failed = data.payment_status === "failed";

    target.className = `order-status ${paid ? "success" : failed ? "error" : "warning"}`;
    target.innerHTML = `
      <strong>${paid ? "✅ Paiement confirmé" : "📦 Commande retrouvée"}</strong>
      <div class="tracking-grid">
        <div><span>Commande</span><b>${escapeHTML(data.order_number)}</b></div>
        <div><span>Montant</span><b>${money(data.total)}</b></div>
        <div><span>Commande</span><b>${escapeHTML(orderStatusLabel(data.order_status))}</b></div>
        <div><span>Paiement</span><b>${escapeHTML(statusLabel(data.payment_status))}</b></div>
      </div>
      ${paid ? `<p>Merci ! Le paiement SumUp est bien confirmé.</p>` : ""}
      ${!paid && data.payment_url ? `<a class="btn sumup-btn" href="${escapeHTML(data.payment_url)}">Reprendre le paiement SumUp</a>` : ""}
      ${!paid ? `<button class="btn secondary" type="button" onclick="retryPayment('${escapeHTML(data.order_number)}','${escapeHTML(email)}')">Créer un nouveau lien SumUp</button>` : ""}
    `;

    rememberOrder(data.order_number, email, data.total, data.payment_url || "");
    return data;
  }catch(err){
    target.className = "order-status error";
    target.textContent = err?.message || "Impossible de retrouver la commande.";
  }
}

async function trackingSubmit(ev){
  ev.preventDefault();
  const fd = new FormData(ev.currentTarget);
  await checkOrderStatus(fd.get("order_number"), fd.get("customer_email"), "trackingResult");
}

async function initThankYouPage(){
  const root = document.getElementById("thankYouStatus");
  if(!root) return;

  const params = new URLSearchParams(location.search);
  const fromUrl = params.get("order");
  const saved = getRememberedOrder();
  const orderNumber = fromUrl || saved?.order_number || "";
  const email = saved?.customer_email || "";

  if(!orderNumber){
    root.className = "order-status warning";
    root.innerHTML = 'Aucun numéro de commande détecté. <a href="suivi.html">Ouvrir le suivi de commande</a>.';
    return;
  }

  document.querySelectorAll("[data-last-order]").forEach(el => el.textContent = orderNumber);

  if(!email){
    root.className = "order-status warning";
    root.innerHTML = `Commande <strong>${escapeHTML(orderNumber)}</strong>. Pour vérifier le paiement, utilise la page <a href="suivi.html">Suivi</a> avec ton e-mail.`;
    return;
  }

  await checkOrderStatus(orderNumber, email, "thankYouStatus");
}

async function submitCustomRequest(ev){
  ev.preventDefault();
  const form = ev.currentTarget;
  const fd = new FormData(form);
  const status = document.getElementById("customStatus");
  const btn = form.querySelector("button[type=submit]");

  if(btn){
    btn.disabled = true;
    btn.textContent = "Transmission à MSTKPRINT37…";
  }

  const type = String(fd.get("type") || "Objet personnalisé").trim();
  const qty = Math.max(1, Number(fd.get("quantity")) || 1);
  const material = String(fd.get("material") || "").trim();
  const color = String(fd.get("color") || "").trim();
  const project = String(fd.get("project") || "").trim();

  const notes = [
    "DEMANDE DE DEVIS / SUR MESURE",
    `Type : ${type}`,
    `Quantité souhaitée : ${qty}`,
    material ? `Matière : ${material}` : "",
    color ? `Couleur : ${color}` : "",
    "",
    project
  ].filter(Boolean).join("\n");

  try{
    const data = await apiPost({
      customer_name:String(fd.get("customer_name")||"").trim(),
      customer_email:String(fd.get("customer_email")||"").trim(),
      customer_phone:String(fd.get("customer_phone")||"").trim(),
      address:"",
      postal_code:"",
      city:"",
      notes,
      coupon_code:"",
      source:"mstkprint37_sur_mesure",
      items:[{
        slug:"creation-3d-personnalisee",
        quantity:1,
        options:{type, quantity_requested:qty, material, color},
        personalization:project
      }]
    });

    if(status){
      status.className = "order-status success";
      status.innerHTML = `<strong>✅ Demande transmise</strong>
        <p>Référence : <strong>${escapeHTML(data.order_number)}</strong></p>
        <p>Ta demande est maintenant enregistrée dans le système MSTKPRINT37 pour préparation du devis.</p>`;
    }
    form.reset();
  }catch(err){
    if(status){
      status.className = "order-status error";
      status.textContent = err?.message || "Impossible d'envoyer la demande.";
    }
  }finally{
    if(btn){
      btn.disabled = false;
      btn.textContent = "Envoyer ma demande de devis";
    }
  }
}

function sendContactWhatsApp(ev){
  ev.preventDefault();
  const fd = new FormData(ev.currentTarget);
  const name = String(fd.get("name")||"").trim();
  const email = String(fd.get("email")||"").trim();
  const message = String(fd.get("message")||"").trim();
  const text = `Bonjour MSTKPRINT37 👋\nJe m'appelle ${name}.\nE-mail : ${email}\n\n${message}`;
  window.open(`https://wa.me/33764027468?text=${encodeURIComponent(text)}`, "_blank", "noopener");
}

document.addEventListener("DOMContentLoaded", () => {
  updateCartCount();
  renderCart();
  renderCheckoutSummary();
  initThankYouPage();
});


/* ===== MINI-JEU MSTKPRINT37 =====
   Limitation locale : 1 partie / 24 h par navigateur.
   À relier plus tard à Supabase pour une limitation réellement côté serveur.
*/
const GAME_KEY = "mstk_game_last_play_v1";
const GAME_RESULT_KEY = "mstk_game_result_v1";

const MSTK_PRIZES = [
  {label:"1 € OFFERT", code:"MSTK1", detail:"1 € de remise dès 6 € d'achat.", weight:30},
  {label:"2 € OFFERTS", code:"MSTK2", detail:"2 € de remise dès 12 € d'achat.", weight:18},
  {label:"5 % OFFERT", code:"MSTK5PC", detail:"5 % de remise dès 10 € d'achat.", weight:20},
  {label:"10 % OFFERT", code:"MSTK10PC", detail:"10 % de remise dès 15 € d'achat.", weight:8},
  {label:"LIVRAISON", code:"MSTKPORT", detail:"Livraison offerte dès 20 € d'achat.", weight:4},
  {label:"À DEMAIN", code:null, detail:"Pas gagné cette fois. Tu peux retenter demain.", weight:20}
];

function pickWeightedPrize(){
  const total = MSTK_PRIZES.reduce((s,p)=>s+p.weight,0);
  let r = Math.random()*total;
  for(let i=0;i<MSTK_PRIZES.length;i++){
    r -= MSTK_PRIZES[i].weight;
    if(r <= 0) return {prize:MSTK_PRIZES[i], index:i};
  }
  return {prize:MSTK_PRIZES[MSTK_PRIZES.length-1], index:MSTK_PRIZES.length-1};
}

function remainingGameTime(){
  const last = Number(localStorage.getItem(GAME_KEY)||0);
  const diff = 24*60*60*1000 - (Date.now()-last);
  return Math.max(0,diff);
}

function formatRemaining(ms){
  const h = Math.floor(ms/3600000);
  const m = Math.ceil((ms%3600000)/60000);
  return `${h} h ${m} min`;
}

function renderSavedGame(){
  const btn = document.querySelector("#spinBtn");
  const status = document.querySelector("#gameStatus");
  const result = document.querySelector("#gameResult");
  if(!btn || !status || !result) return;
  const remaining = remainingGameTime();
  if(remaining>0){
    btn.disabled = true;
    btn.style.opacity = ".55";
    status.textContent = "Prochaine partie dans " + formatRemaining(remaining) + ".";
    try{
      const saved = JSON.parse(localStorage.getItem(GAME_RESULT_KEY)||"null");
      if(saved){
        result.className = "game-result " + (saved.code ? "win":"");
        result.innerHTML = saved.code
          ? `<strong>🎉 Ton dernier gain : ${saved.label}</strong><p>${saved.detail}</p><div class="game-code"><span class="coupon">${saved.code}</span><button class="btn secondary" onclick="copyGameCode('${saved.code}')">Copier le code</button></div>`
          : `<strong>🍀 ${saved.label}</strong><p>${saved.detail}</p>`;
      }
    }catch(e){}
  }else{
    btn.disabled = false;
    btn.style.opacity = "1";
    status.textContent = "Tu peux jouer maintenant.";
  }
}

function spinMstkWheel(){
  const btn = document.querySelector("#spinBtn");
  const wheel = document.querySelector("#wheel");
  const result = document.querySelector("#gameResult");
  if(!btn || !wheel || !result) return;

  const remaining = remainingGameTime();
  if(remaining>0){
    renderSavedGame();
    return;
  }

  btn.disabled = true;
  const {prize,index} = pickWeightedPrize();

  // 6 sections of 60°. Pointer at top. Add several full rotations.
  const centerAngle = index*60 + 30;
  const stopAngle = 360 - centerAngle;
  const totalRotation = 360*7 + stopAngle;
  wheel.style.transform = `rotate(${totalRotation}deg)`;

  result.className = "game-result";
  result.innerHTML = "<strong>La roue tourne… 🎡</strong><p>Bonne chance !</p>";

  setTimeout(()=>{
    localStorage.setItem(GAME_KEY, String(Date.now()));
    localStorage.setItem(GAME_RESULT_KEY, JSON.stringify(prize));
    if(prize.code){
      result.className = "game-result win";
      result.innerHTML = `<strong>🎉 Bravo ! Tu gagnes : ${prize.label}</strong><p>${prize.detail}</p><div class="game-code"><span class="coupon">${prize.code}</span><button class="btn secondary" onclick="copyGameCode('${prize.code}')">Copier le code</button></div>`;
    }else{
      result.className = "game-result";
      result.innerHTML = `<strong>🍀 ${prize.label}</strong><p>${prize.detail}</p>`;
    }
    renderSavedGame();
  },4600);
}

function copyGameCode(code){
  navigator.clipboard?.writeText(code).then(()=>{
    alert("Code copié : "+code);
  }).catch(()=>{
    prompt("Copie ce code :", code);
  });
}

document.addEventListener("DOMContentLoaded", renderSavedGame);


/* ===== LA BUSE CHANCEUSE + MISSIONS / 2E CHANCE ===== */
const NOZZLE_GAME_KEY = "mstk_lucky_nozzle_last_v1";
const NOZZLE_RESULT_KEY = "mstk_lucky_nozzle_result_v1";
const NOZZLE_BONUS_KEY = "mstk_lucky_nozzle_bonus_v2";
const NOZZLE_SOCIAL = {
  instagram: "https://www.instagram.com/mstkprint37/",
  youtube: "https://www.youtube.com/@mstkprint37"
};

const NOZZLE_PRIZES = [
  {label:"1 € OFFERT", code:"BUSE1", detail:"1 € de remise dès 6 € d'achat.", weight:30, rank:10},
  {label:"2 € OFFERTS", code:"BUSE2", detail:"2 € de remise dès 12 € d'achat.", weight:18, rank:20},
  {label:"5 % OFFERT", code:"BUSE5", detail:"5 % de remise dès 10 € d'achat.", weight:20, rank:25},
  {label:"10 % OFFERT", code:"BUSE10", detail:"10 % de remise dès 15 € d'achat.", weight:8, rank:40},
  {label:"PORT OFFERT", code:"BUSEPORT", detail:"Livraison offerte dès 20 € d'achat.", weight:4, rank:35},
  {label:"REJOUE DEMAIN", code:null, detail:"La buse n'a rien imprimé cette fois.", weight:20, rank:0}
];

function nozzlePick(){
  const total = NOZZLE_PRIZES.reduce((a,p)=>a+p.weight,0);
  let r = Math.random()*total;
  for(let i=0;i<NOZZLE_PRIZES.length;i++){
    r -= NOZZLE_PRIZES[i].weight;
    if(r<=0) return {p:NOZZLE_PRIZES[i],i};
  }
  return {p:NOZZLE_PRIZES[5],i:5};
}

function nozzleRemaining(){
  const last = Number(localStorage.getItem(NOZZLE_GAME_KEY)||0);
  return Math.max(0,86400000-(Date.now()-last));
}

function nozzleTime(ms){
  const h=Math.floor(ms/3600000);
  const m=Math.ceil((ms%3600000)/60000);
  return `${h} h ${m} min`;
}

function nozzleLoadBonus(){
  const cycle=Number(localStorage.getItem(NOZZLE_GAME_KEY)||0);
  let state={cycle,opened:null,ready:false,used:false};
  try{
    const saved=JSON.parse(localStorage.getItem(NOZZLE_BONUS_KEY)||"null");
    if(saved && Number(saved.cycle)===cycle) state={...state,...saved};
  }catch(e){}
  return state;
}

function nozzleSaveBonus(state){
  localStorage.setItem(NOZZLE_BONUS_KEY,JSON.stringify(state));
}

function nozzleCanBonus(){
  if(nozzleRemaining()<=0) return false;
  const state=nozzleLoadBonus();
  return !!(state.ready && !state.used);
}

function nozzlePrizeRank(prize){
  if(!prize) return -1;
  if(typeof prize.rank === "number") return prize.rank;
  const match=NOZZLE_PRIZES.find(x=>x.code===prize.code && x.label===prize.label);
  return match ? match.rank : (prize.code ? 1 : 0);
}

function nozzleRenderMission(){
  const box=document.querySelector("#luckyMissionBox");
  const choices=document.querySelector("#luckyMissionChoices");
  const confirm=document.querySelector("#luckyMissionConfirm");
  if(!box||!choices||!confirm) return;

  const remain=nozzleRemaining();
  if(remain<=0){
    box.hidden=true;
    localStorage.removeItem(NOZZLE_BONUS_KEY);
    return;
  }

  const state=nozzleLoadBonus();
  if(state.used || state.ready){
    box.hidden=true;
    return;
  }

  box.hidden=false;
  choices.hidden=!!state.opened;
  confirm.hidden=!state.opened;
}

function nozzleRenderSaved(preserveOutput=false){
  const btn=document.querySelector("#luckyNozzleBtn");
  const info=document.querySelector("#luckyNozzleInfo");
  const out=document.querySelector("#luckyNozzleResult");
  if(!btn||!info||!out) return;
  const remain=nozzleRemaining();

  if(remain>0){
    const bonus=nozzleLoadBonus();
    if(bonus.ready && !bonus.used){
      btn.disabled=false;
      btn.style.opacity="1";
      btn.textContent="🎁 Lancer ma 2e chance";
      info.innerHTML='<span class="lucky-bonus-ready">2e chance débloquée : tu peux rejouer maintenant.</span>';
    }else{
      btn.disabled=true;
      btn.style.opacity=".55";
      btn.textContent="🖨️ Lancer l'impression chanceuse";
      info.textContent="Prochaine tentative gratuite dans "+nozzleTime(remain)+".";
    }
    if(!preserveOutput){
      try{
        const saved=JSON.parse(localStorage.getItem(NOZZLE_RESULT_KEY)||"null");
        if(saved){
          out.className="lucky-result "+(saved.code?"win":"");
          out.innerHTML=saved.code
            ? `<strong>🎉 Ton meilleur gain : ${saved.label}</strong><div>${saved.detail}</div><div class="lucky-code">${saved.code} <button class="btn secondary" style="padding:7px 10px" onclick="copyLuckyCode('${saved.code}')">Copier</button></div>`
            : `<strong>🍀 ${saved.label}</strong><div>${saved.detail}</div>`;
        }
      }catch(e){}
    }
  }else{
    btn.disabled=false;
    btn.style.opacity="1";
    btn.textContent="🖨️ Lancer l'impression chanceuse";
    info.textContent="1 tentative toutes les 24 h sur ce navigateur.";
    localStorage.removeItem(NOZZLE_BONUS_KEY);
  }
  nozzleRenderMission();
}

function openLuckyMission(source){
  const url=NOZZLE_SOCIAL[source];
  if(!url || nozzleRemaining()<=0) return;
  const state=nozzleLoadBonus();
  if(state.used || state.ready) return;
  state.opened=source;
  state.openedAt=Date.now();
  nozzleSaveBonus(state);
  window.open(url,"_blank","noopener");
  nozzleRenderMission();
}

function confirmLuckyMission(){
  if(nozzleRemaining()<=0) return;
  const state=nozzleLoadBonus();
  if(!state.opened || state.used) return;
  state.ready=true;
  state.confirmedAt=Date.now();
  nozzleSaveBonus(state);
  nozzleRenderSaved(true);
}

function copyLuckyCode(code){
  navigator.clipboard?.writeText(code).then(()=>alert("Code copié : "+code)).catch(()=>prompt("Copie ce code :",code));
}

function playLuckyNozzle(){
  const btn=document.querySelector("#luckyNozzleBtn");
  const head=document.querySelector("#luckyHead");
  const filament=document.querySelector("#luckyFilament");
  const dot=document.querySelector("#printedDot");
  const out=document.querySelector("#luckyNozzleResult");
  const slots=[...document.querySelectorAll(".lucky-slot")];
  if(!btn||!head||!filament||!dot||!out||!slots.length) return;

  const isBonus=nozzleCanBonus();
  if(nozzleRemaining()>0 && !isBonus){nozzleRenderSaved();return;}

  btn.disabled=true;
  slots.forEach(s=>s.classList.remove("active"));
  dot.classList.remove("show");
  filament.style.height="0";
  out.className="lucky-result";
  out.innerHTML=isBonus
    ? "<strong>🎁 La seconde chance est lancée…</strong><div>La buse cherche si elle peut améliorer ton gain.</div>"
    : "<strong>🖨️ La buse cherche ta récompense…</strong><div>Impression en cours.</div>";

  const {p,i}=nozzlePick();
  const positions=[8.33,25,41.67,58.33,75,91.67];
  const seq=[2,4,1,5,0,3,i];
  seq.forEach((idx,n)=>{
    setTimeout(()=>{
      head.style.left=positions[idx]+"%";
      slots.forEach(s=>s.classList.remove("active"));
      slots[idx].classList.add("active");
    },n*270);
  });

  setTimeout(()=>{
    head.style.left=positions[i]+"%";
    slots.forEach(s=>s.classList.remove("active"));
    slots[i].classList.add("active");
    filament.style.left=positions[i]+"%";
    filament.style.height="155px";
  },2050);

  setTimeout(()=>{
    filament.style.height="0";
    dot.style.left=positions[i]+"%";
    dot.classList.remove("show");
    void dot.offsetWidth;
    dot.classList.add("show");
  },2820);

  setTimeout(()=>{
    if(isBonus){
      const state=nozzleLoadBonus();
      state.ready=false;
      state.used=true;
      state.usedAt=Date.now();
      nozzleSaveBonus(state);

      let previous=null;
      try{previous=JSON.parse(localStorage.getItem(NOZZLE_RESULT_KEY)||"null");}catch(e){}
      const improved=nozzlePrizeRank(p)>nozzlePrizeRank(previous);
      const best=improved ? p : (previous||p);
      localStorage.setItem(NOZZLE_RESULT_KEY,JSON.stringify(best));

      if(best.code){
        out.className="lucky-result win";
        out.innerHTML=improved
          ? `<strong>🚀 Ta 2e chance améliore ton gain : ${best.label}</strong><div>${best.detail}</div><div class="lucky-code">${best.code} <button class="btn secondary" style="padding:7px 10px" onclick="copyLuckyCode('${best.code}')">Copier</button></div>`
          : `<strong>🛡️ Ton premier gain reste le meilleur : ${best.label}</strong><div>Le 2e tirage était « ${p.label} ». Tu gardes automatiquement le meilleur avantage.</div><div class="lucky-code">${best.code} <button class="btn secondary" style="padding:7px 10px" onclick="copyLuckyCode('${best.code}')">Copier</button></div>`;
      }else{
        out.className="lucky-result";
        out.innerHTML=`<strong>🍀 Deuxième chance utilisée</strong><div>${p.detail} Reviens demain pour une nouvelle tentative.</div>`;
      }
    }else{
      const cycle=Date.now();
      localStorage.setItem(NOZZLE_GAME_KEY,String(cycle));
      localStorage.setItem(NOZZLE_RESULT_KEY,JSON.stringify(p));
      nozzleSaveBonus({cycle,opened:null,ready:false,used:false});
      if(p.code){
        out.className="lucky-result win";
        out.innerHTML=`<strong>🎉 La buse a imprimé : ${p.label}</strong><div>${p.detail}</div><div class="lucky-code">${p.code} <button class="btn secondary" style="padding:7px 10px" onclick="copyLuckyCode('${p.code}')">Copier</button></div>`;
      }else{
        out.className="lucky-result";
        out.innerHTML=`<strong>🍀 ${p.label}</strong><div>${p.detail} Tu peux encore débloquer une 2e chance avec une mission.</div>`;
      }
    }
    nozzleRenderSaved(true);
  },3500);
}

document.addEventListener("DOMContentLoaded",nozzleRenderSaved);


/* Préremplit le type de demande depuis le catalogue */
document.addEventListener("DOMContentLoaded",()=>{
  const select=document.querySelector("#customType");
  if(!select) return;
  const requested=new URLSearchParams(location.search).get("type");
  if(!requested) return;
  const option=[...select.options].find(o=>o.value.toLowerCase()===requested.toLowerCase() || o.textContent.trim().toLowerCase()===requested.toLowerCase());
  if(option){select.value=option.value;}
});
